# Speaker Notes: Executive Analytics Capstone — Customer Churn Presentation

---

### Slide 1: Title & Decision Question
Good morning, leadership team. Today we present our findings on customer retention, answering our core decision question: *Which customers are most likely to churn, and what should we do first?* We have distilled our exploratory analytics and predictive risk modeling into a clear, explainable operational roadmap to protect our recurring revenue.

---

### Slide 2: Executive Summary
To summarize upfront: our historical cohort exhibited a 46.7% churn rate, representing $409.93 in monthly lost revenue, driven entirely by month-to-month contracts and high technical support friction. Looking prospectively at our active accounts, we have identified two medium-risk customers representing $129.98 in monthly recurring revenue who require immediate attention. We propose three sequenced actions over 90 days—onboarding support triage, annual contract migration discounts, and dedicated enterprise reviews—to systematically prevent further churn.

---

### Slide 3: Data & Method in Plain Language
Our analysis is based on an audited dataset of 15 customer accounts, cleaned and verified with zero missing values, zero duplicates, and strict financial consistency across billing fields. Because this is a compact synthetic sample, we treat every observed pattern as an illustrative operating hypothesis rather than a statistically proven truth. We deliberately used transparent, rule-based methods rather than black-box algorithms so that every score and segment is completely auditable and explainable to front-line teams.

---

### Slide 4: Headline KPIs
Across the portfolio, 7 of 15 accounts have churned, resulting in a 46.7% churn rate and $409.93 per month in lost recurring revenue, which accounts for 32.3% of total portfolio MRR. While strict historical rules identified zero active accounts with high tickets on monthly plans, our prospective risk model flags $129.98 per month in active accounts facing renewal friction. Crucially, churned customers left after an average of only 7.0 months, compared to an average tenure of 29.1 months among retained accounts.

---

### Slide 5: What Drives Churn
The data reveals three clear drivers of cancellation: contract structure, customer lifecycle stage, and support experience. Month-to-month subscribers experienced 100% churn in this sample, whereas customers on one-year and two-year agreements experienced zero churn. Furthermore, churned customers averaged 4.29 support tickets compared to just 1.00 for retained customers, indicating that unaddressed product friction within the first 12 months is the primary operational trigger for customer departure.

---

### Slide 6: Customer Segments
We categorized our customer base into three distinct behavioral cohorts to enable targeted operational responses. High-Friction Starters represent 46.7% of accounts on monthly plans who encountered high support friction and churned early. Mid-Tenure Stabilizers represent 26.7% of accounts on annual plans generating $259.96 in monthly revenue; they are currently active but need renewal stewardship. Finally, Enterprise Anchors represent 26.7% of accounts on two-year agreements generating $599.96 in monthly revenue, providing our stable baseline.

---

### Slide 7: Churn-Risk Score & Priority List
We built an explainable 0-to-5 point churn-risk score that assigns points for contract flexibility, support ticket volume, and early tenure. When applied to our active base, it cleanly segments accounts into risk tiers, highlighting accounts CUST-1009 and CUST-1006 as our top triage priorities. CUST-1009 pays $79.99 monthly on a Pro plan with two unresolved support tickets at 15 months of tenure, while CUST-1006 pays $49.99 monthly with similar ticket friction.

---

### Slide 8: Strategic Recommendations
We recommend three prioritized interventions mapped directly to each segment with assigned owners and timelines. In Days 1 through 30, the Customer Success Lead will institute proactive check-ins for any user submitting two or more tickets during onboarding. In Days 30 through 60, Sales and Growth will offer a 15% discount incentive to migrate accounts CUST-1009 and CUST-1006 into annual contracts. In Days 60 through 90, Strategic Account Management will formalize quarterly value reviews to protect our $599.96 monthly enterprise foundation.

---

### Slide 9: Expected Impact
To evaluate commercial viability, we modeled three transparent scenarios based on explicit assumptions rather than guaranteed forecasts. In our base case, achieving a 30% retention lift among active at-risk accounts preserves $38.99 per month, while deflecting 25% of prospective early-stage churn saves an additional $102.48 per month, totaling $141.48 monthly or approximately $1,698 annually. Even under conservative assumptions of a 15% lift, the strategy preserves over $60 monthly in recurring revenue.

---

### Slide 10: Limitations & Next Steps
We must emphasize key analytical limitations: this synthetic sample of 15 records contains no time-series timestamps, and the rule-based score was calibrated in-sample without causal proof. Before full-scale rollout, our immediate next step is to execute a controlled A/B test of the 15% annual migration offer to measure price elasticity and net retention. Concurrently, we will expand data collection across 250 to 500 live customer accounts to validate our risk scoring thresholds with true statistical rigor.

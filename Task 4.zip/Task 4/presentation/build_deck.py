import os
import sys
import pandas as pd
import numpy as np
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

# -------------------------------------------------------------
# CONSTANTS & OKABE-ITO COLOR PALETTE
# -------------------------------------------------------------
FONT_TITLE = 'Arial'
FONT_BODY = 'Arial'

COLOR_BG_LIGHT = RGBColor(248, 249, 250)      # #F8F9FA
COLOR_CARD_BORDER = RGBColor(220, 224, 230)   # Light Gray Border
COLOR_TEXT_DARK = RGBColor(43, 43, 43)        # #2B2B2B Primary Dark
COLOR_TEXT_MUTED = RGBColor(95, 105, 115)     # #5F6973 Secondary Text
COLOR_BLUE = RGBColor(0, 114, 178)            # #0072B2 Okabe-Ito Blue
COLOR_VERMILION = RGBColor(213, 94, 0)        # #D55E00 Okabe-Ito Vermilion
COLOR_GREEN = RGBColor(0, 158, 115)           # #009E73 Okabe-Ito Bluish Green
COLOR_ORANGE = RGBColor(230, 159, 0)          # #E69F00 Okabe-Ito Orange
COLOR_WHITE = RGBColor(255, 255, 255)         # Pure White
COLOR_ACCENT_BG = RGBColor(237, 244, 251)     # Very light blue tint

def set_alt_text(shape, descr):
    try:
        shape._element.nvPicPr.cNvPr.set('descr', descr)
    except Exception:
        pass

def add_header(slide, title_text, takeaway_text):
    # Title Box
    title_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.4), Inches(11.7), Inches(0.65))
    tf = title_box.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_top = tf.margin_right = tf.margin_bottom = 0
    p = tf.paragraphs[0]
    p.text = title_text
    p.font.name = FONT_TITLE
    p.font.size = Pt(26)
    p.font.bold = True
    p.font.color.rgb = COLOR_TEXT_DARK

    # Action Headline / Takeaway (under 30 words)
    takeaway_box = slide.shapes.add_textbox(Inches(0.8), Inches(1.05), Inches(11.7), Inches(0.55))
    tf2 = takeaway_box.text_frame
    tf2.word_wrap = True
    tf2.margin_left = tf2.margin_top = tf2.margin_right = tf2.margin_bottom = 0
    p2 = tf2.paragraphs[0]
    p2.text = takeaway_text
    p2.font.name = FONT_BODY
    p2.font.size = Pt(17)
    p2.font.bold = True
    p2.font.color.rgb = COLOR_BLUE

def add_source_line(slide, text="Source: customer_churn_sample.csv, n = 15 (illustrative synthetic sample)"):
    box = slide.shapes.add_textbox(Inches(0.8), Inches(6.9), Inches(11.7), Inches(0.35))
    tf = box.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_top = tf.margin_right = tf.margin_bottom = 0
    p = tf.paragraphs[0]
    p.text = text
    p.font.name = FONT_BODY
    p.font.size = Pt(11)
    p.font.italic = True
    p.font.color.rgb = COLOR_TEXT_MUTED

def add_card(slide, left, top, width, height, bg_color=COLOR_BG_LIGHT, border_color=COLOR_CARD_BORDER):
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = bg_color
    shape.line.color.rgb = border_color
    shape.line.width = Pt(1.5)
    return shape

def format_cell(cell, text, font_size=13, bold=False, color=COLOR_TEXT_DARK, align=PP_ALIGN.LEFT, bg_color=None):
    cell.text = text
    cell.vertical_anchor = MSO_ANCHOR.MIDDLE
    if bg_color:
        cell.fill.solid()
        cell.fill.fore_color.rgb = bg_color
    p = cell.text_frame.paragraphs[0]
    p.alignment = align
    p.font.name = FONT_BODY
    p.font.size = Pt(font_size)
    p.font.bold = bold
    p.font.color.rgb = color

# -------------------------------------------------------------
# MAIN DECK BUILDER FUNCTION
# -------------------------------------------------------------
def build_deck():
    os.makedirs('presentation', exist_ok=True)
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank_layout = prs.slide_layouts[6]

    # =========================================================
    # SLIDE 1: TITLE & DECISION QUESTION
    # =========================================================
    slide1 = prs.slides.add_slide(blank_layout)
    
    # Outer decorative card
    add_card(slide1, Inches(0.8), Inches(0.8), Inches(11.733), Inches(5.9), COLOR_BG_LIGHT, COLOR_BLUE)
    
    # Title
    t_box = slide1.shapes.add_textbox(Inches(1.4), Inches(1.3), Inches(10.5), Inches(1.5))
    tf = t_box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = "Customer Churn Analysis & Retention Strategy"
    p.font.name = FONT_TITLE
    p.font.size = Pt(36)
    p.font.bold = True
    p.font.color.rgb = COLOR_TEXT_DARK
    
    p_sub = tf.add_paragraph()
    p_sub.text = "Executive Analytics Capstone — Transparent Prioritization Roadmap"
    p_sub.font.name = FONT_BODY
    p_sub.font.size = Pt(20)
    p_sub.font.bold = True
    p_sub.font.color.rgb = COLOR_BLUE
    p_sub.space_before = Pt(8)

    # Decision Question Callout Card
    dq_card = add_card(slide1, Inches(1.4), Inches(3.2), Inches(10.5), Inches(1.6), COLOR_ACCENT_BG, COLOR_BLUE)
    dq_box = slide1.shapes.add_textbox(Inches(1.6), Inches(3.35), Inches(10.1), Inches(1.3))
    tf_dq = dq_box.text_frame
    tf_dq.word_wrap = True
    p_lbl = tf_dq.paragraphs[0]
    p_lbl.text = "EXECUTIVE DECISION QUESTION:"
    p_lbl.font.size = Pt(13)
    p_lbl.font.bold = True
    p_lbl.font.color.rgb = COLOR_BLUE
    
    p_q = tf_dq.add_paragraph()
    p_q.text = "“Which customers are most likely to churn, and what should we do first?”"
    p_q.font.size = Pt(21)
    p_q.font.bold = True
    p_q.font.color.rgb = COLOR_TEXT_DARK
    p_q.space_before = Pt(4)

    # Metadata footer
    m_box = slide1.shapes.add_textbox(Inches(1.4), Inches(5.2), Inches(10.5), Inches(0.8))
    tf_m = m_box.text_frame
    p_m = tf_m.paragraphs[0]
    p_m.text = "Prepared by: Senior Data Analyst  |  Audience: Executive Leadership  |  Data: customer_churn_clean.csv (n = 15)"
    p_m.font.size = Pt(14)
    p_m.font.color.rgb = COLOR_TEXT_MUTED

    # =========================================================
    # SLIDE 2: EXECUTIVE SUMMARY (3 Findings & 3 Recommendations)
    # =========================================================
    slide2 = prs.slides.add_slide(blank_layout)
    add_header(slide2, "Executive Summary", 
               "Three key findings explain churn and anchor our 90-day retention roadmap.")
    
    # Left Card: 3 Key Findings
    add_card(slide2, Inches(0.8), Inches(1.7), Inches(5.7), Inches(5.0), COLOR_BG_LIGHT, COLOR_CARD_BORDER)
    f_box = slide2.shapes.add_textbox(Inches(1.0), Inches(1.85), Inches(5.3), Inches(4.7))
    tf_f = f_box.text_frame
    tf_f.word_wrap = True
    
    p = tf_f.paragraphs[0]
    p.text = "3 KEY FINDINGS (Audited Data)"
    p.font.size = Pt(17)
    p.font.bold = True
    p.font.color.rgb = COLOR_VERMILION

    findings = [
        ("46.7% Churn Rate ($409.93/mo Lost):", " 7 of 15 customers churned, representing 32.3% of total portfolio recurring revenue."),
        ("100% Churn in Month-to-Month:", " All 7 churned accounts were monthly subscribers averaging 4.29 support tickets."),
        ("$129.98/mo Active Risk Exposure:", " 2 active accounts (CUST-1009, CUST-1006) show elevated medium risk due to tickets and renewals.")
    ]
    for title, desc in findings:
        pf = tf_f.add_paragraph()
        pf.space_before = Pt(14)
        run1 = pf.add_run()
        run1.text = "• " + title
        run1.font.bold = True
        run1.font.size = Pt(14)
        run1.font.color.rgb = COLOR_TEXT_DARK
        run2 = pf.add_run()
        run2.text = desc
        run2.font.size = Pt(14)
        run2.font.color.rgb = COLOR_TEXT_MUTED

    # Right Card: 3 Recommendations
    add_card(slide2, Inches(6.8), Inches(1.7), Inches(5.7), Inches(5.0), COLOR_BG_LIGHT, COLOR_CARD_BORDER)
    r_box = slide2.shapes.add_textbox(Inches(7.0), Inches(1.85), Inches(5.3), Inches(4.7))
    tf_r = r_box.text_frame
    tf_r.word_wrap = True
    
    p_r = tf_r.paragraphs[0]
    p_r.text = "3 PRIORITIZED ACTIONS (90 Days)"
    p_r.font.size = Pt(17)
    p_r.font.bold = True
    p_r.font.color.rgb = COLOR_GREEN

    recs = [
        ("Days 1–30: Support Triage (CS Lead):", " Reach out within 24h when tickets ≥ 2 to defuse onboarding friction for new subscribers."),
        ("Days 30–60: 15% Annual Discount (Sales):", " Incentivize accounts CUST-1009 & CUST-1006 to commit to annual terms before renewal."),
        ("Days 60–90: Enterprise QBRs (Account Mgmt):", " Conduct executive reviews across all 4 enterprise accounts to protect $599.96/mo revenue.")
    ]
    for title, desc in recs:
        pr = tf_r.add_paragraph()
        pr.space_before = Pt(14)
        run1 = pr.add_run()
        run1.text = "• " + title
        run1.font.bold = True
        run1.font.size = Pt(14)
        run1.font.color.rgb = COLOR_TEXT_DARK
        run2 = pr.add_run()
        run2.text = desc
        run2.font.size = Pt(14)
        run2.font.color.rgb = COLOR_TEXT_MUTED

    add_source_line(slide2)

    # =========================================================
    # SLIDE 3: DATA AND METHOD IN PLAIN LANGUAGE
    # =========================================================
    slide3 = prs.slides.add_slide(blank_layout)
    add_header(slide3, "Data & Methodology Overview", 
               "Audited synthetic dataset establishing transparent, explainable decision rules.")

    col_w = Inches(3.64)
    # Card 1: Dataset Profile
    add_card(slide3, Inches(0.8), Inches(1.7), col_w, Inches(4.9), COLOR_BG_LIGHT)
    b1 = slide3.shapes.add_textbox(Inches(0.95), Inches(1.85), Inches(3.34), Inches(4.6))
    tf1 = b1.text_frame
    tf1.word_wrap = True
    p = tf1.paragraphs[0]
    p.text = "1. DATASET PROFILE"
    p.font.size = Pt(16)
    p.font.bold = True
    p.font.color.rgb = COLOR_BLUE

    items1 = [
        ("Source:", " customer_churn_sample.csv"),
        ("Dimensions:", " 15 records × 11 fields"),
        ("Clean Table:", " 12 fields (+Churn_Flag)"),
        ("Quality Check:", " 0 nulls, 0 duplicates"),
        ("Completeness:", " 100% verified complete")
    ]
    for k, v in items1:
        p = tf1.add_paragraph()
        p.space_before = Pt(10)
        r1 = p.add_run()
        r1.text = k
        r1.font.bold = True
        r1.font.size = Pt(14)
        r1.font.color.rgb = COLOR_TEXT_DARK
        r2 = p.add_run()
        r2.text = v
        r2.font.size = Pt(14)
        r2.font.color.rgb = COLOR_TEXT_MUTED

    # Card 2: Cleaning & Validation
    add_card(slide3, Inches(4.84), Inches(1.7), col_w, Inches(4.9), COLOR_BG_LIGHT)
    b2 = slide3.shapes.add_textbox(Inches(4.99), Inches(1.85), Inches(3.34), Inches(4.6))
    tf2 = b2.text_frame
    tf2.word_wrap = True
    p = tf2.paragraphs[0]
    p.text = "2. CLEANING & CHECKS"
    p.font.size = Pt(16)
    p.font.bold = True
    p.font.color.rgb = COLOR_BLUE

    items2 = [
        ("Type Assertion:", " Strict int & float types"),
        ("String Trimming:", " Whitespace stripped"),
        ("Charge Formula:", " Total ≈ Monthly × Tenure"),
        ("Tolerance Pass:", " 15 of 15 pass (±$0.05)"),
        ("Validation Suite:", " 12 of 12 tests passed")
    ]
    for k, v in items2:
        p = tf2.add_paragraph()
        p.space_before = Pt(10)
        r1 = p.add_run()
        r1.text = k
        r1.font.bold = True
        r1.font.size = Pt(14)
        r1.font.color.rgb = COLOR_TEXT_DARK
        r2 = p.add_run()
        r2.text = v
        r2.font.size = Pt(14)
        r2.font.color.rgb = COLOR_TEXT_MUTED

    # Card 3: Methodology & Caveat
    add_card(slide3, Inches(8.88), Inches(1.7), col_w, Inches(4.9), COLOR_ACCENT_BG, COLOR_ORANGE)
    b3 = slide3.shapes.add_textbox(Inches(9.03), Inches(1.85), Inches(3.34), Inches(4.6))
    tf3 = b3.text_frame
    tf3.word_wrap = True
    p = tf3.paragraphs[0]
    p.text = "3. METHOD & CAVEAT"
    p.font.size = Pt(16)
    p.font.bold = True
    p.font.color.rgb = COLOR_ORANGE

    items3 = [
        ("Analysis Mode:", " Transparent rules, no black boxes"),
        ("Scoring Logic:", " 0–5 point additive model"),
        ("Small Sample:", " n = 15 synthetic records"),
        ("Interpretation:", " Illustrative operational patterns"),
        ("No Causality:", " Benchmarks, not proven proofs")
    ]
    for k, v in items3:
        p = tf3.add_paragraph()
        p.space_before = Pt(10)
        r1 = p.add_run()
        r1.text = k
        r1.font.bold = True
        r1.font.size = Pt(14)
        r1.font.color.rgb = COLOR_TEXT_DARK
        r2 = p.add_run()
        r2.text = v
        r2.font.size = Pt(14)
        r2.font.color.rgb = COLOR_TEXT_MUTED

    add_source_line(slide3)

    # =========================================================
    # SLIDE 4: HEADLINE KPIS
    # =========================================================
    slide4 = prs.slides.add_slide(blank_layout)
    add_header(slide4, "Portfolio Headline KPIs", 
               "High monthly churn contrasts sharply with long-term enterprise retention stability.")

    # Insert KPI Summary Graphic
    kpi_img = slide4.shapes.add_picture('presentation/figures/fig4_kpi_cards.png', 
                                       Inches(0.8), Inches(1.75), width=Inches(11.733))
    set_alt_text(kpi_img, "Executive KPI summary cards displaying churn rate 46.7%, retention rate 53.3%, monthly revenue lost $409.93, active at-risk revenue $129.98, and average tenure 18.8 months.")

    # Comparison Table below KPI cards
    t_shape = slide4.shapes.add_table(4, 5, Inches(0.8), Inches(4.45), Inches(11.733), Inches(2.2))
    table = t_shape.table
    table.columns[0].width = Inches(2.7)
    table.columns[1].width = Inches(2.2)
    table.columns[2].width = Inches(2.2)
    table.columns[3].width = Inches(2.2)
    table.columns[4].width = Inches(2.433)

    headers = ["Segment / Status", "Customers (n)", "Monthly Revenue", "Avg Tenure", "Avg Support Tickets"]
    for col_idx, h in enumerate(headers):
        format_cell(table.cell(0, col_idx), h, font_size=13, bold=True, color=COLOR_WHITE, 
                    align=PP_ALIGN.CENTER if col_idx > 0 else PP_ALIGN.LEFT, bg_color=COLOR_BLUE)

    rows_data = [
        ["Total Portfolio", "15 accounts", "$1,269.85 / mo", "18.80 months", "2.53 tickets"],
        ["Churned Cohort", "7 accounts (46.7%)", "$409.93 / mo (Lost)", "7.00 months", "4.29 tickets"],
        ["Retained Cohort", "8 accounts (53.3%)", "$859.92 / mo (Active)", "29.13 months", "1.00 ticket"]
    ]
    for row_idx, r_data in enumerate(rows_data, 1):
        bg = COLOR_ACCENT_BG if row_idx == 3 else (COLOR_BG_LIGHT if row_idx == 1 else COLOR_WHITE)
        for col_idx, val in enumerate(r_data):
            c_color = COLOR_VERMILION if "Lost" in val else (COLOR_GREEN if "Active" in val else COLOR_TEXT_DARK)
            format_cell(table.cell(row_idx, col_idx), val, font_size=13, bold=(col_idx==0 or "Lost" in val or "Active" in val),
                        color=c_color, align=PP_ALIGN.CENTER if col_idx > 0 else PP_ALIGN.LEFT, bg_color=bg)

    add_source_line(slide4)

    # =========================================================
    # SLIDE 5: WHAT DRIVES CHURN (Visual Drivers)
    # =========================================================
    slide5 = prs.slides.add_slide(blank_layout)
    add_header(slide5, "Primary Churn Drivers", 
               "Month-to-month contracts and early technical friction drive customer cancellation.")

    # 3 Charts side-by-side
    img_w = Inches(3.75)
    c1 = slide5.shapes.add_picture('presentation/figures/fig1_contract_churn.png', Inches(0.8), Inches(1.8), width=img_w)
    set_alt_text(c1, "Bar chart showing 100% churn in Month-to-Month contracts versus 0% churn in One-Year and Two-Year contracts.")

    c2 = slide5.shapes.add_picture('presentation/figures/fig2_tenure_churn.png', Inches(4.79), Inches(1.8), width=img_w)
    set_alt_text(c2, "Bar chart illustrating churn by tenure band: 100% churn in 0-6 and 7-12 months versus 0% in 25+ months.")

    c3 = slide5.shapes.add_picture('presentation/figures/fig3_tickets_churn.png', Inches(8.78), Inches(1.8), width=img_w)
    set_alt_text(c3, "Bar chart comparing support tickets: churned customers averaged 4.29 tickets versus 1.00 for retained customers.")

    # Summary Takeaway Card (under 30 words)
    add_card(slide5, Inches(0.8), Inches(5.75), Inches(11.733), Inches(0.95), COLOR_ACCENT_BG, COLOR_BLUE)
    t_box = slide5.shapes.add_textbox(Inches(1.0), Inches(5.82), Inches(11.3), Inches(0.8))
    tf = t_box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = "Key Takeaway: Customers on flexible monthly plans who log 3 or more support tickets within their first 12 months face critical churn risk and require immediate intervention."
    p.font.size = Pt(14)
    p.font.bold = True
    p.font.color.rgb = COLOR_TEXT_DARK

    add_source_line(slide5)

    # =========================================================
    # SLIDE 6: CUSTOMER SEGMENTS (Table & Stories)
    # =========================================================
    slide6 = prs.slides.add_slide(blank_layout)
    add_header(slide6, "Customer Behavioral Segments", 
               "Three behavioral cohorts require distinct operational retention strategies.")

    # Table of Segments
    t_shape = slide6.shapes.add_table(4, 7, Inches(0.8), Inches(1.8), Inches(11.733), Inches(4.8))
    table = t_shape.table
    table.columns[0].width = Inches(2.2)
    table.columns[1].width = Inches(1.1)
    table.columns[2].width = Inches(1.5)
    table.columns[3].width = Inches(1.4)
    table.columns[4].width = Inches(1.3)
    table.columns[5].width = Inches(1.3)
    table.columns[6].width = Inches(2.933)

    headers = ["Segment Name", "Size", "Contract", "Monthly Rev", "Avg Tenure", "Churn", "Strategic Segment Story"]
    for col_idx, h in enumerate(headers):
        format_cell(table.cell(0, col_idx), h, font_size=13, bold=True, color=COLOR_WHITE, 
                    align=PP_ALIGN.CENTER if 0 < col_idx < 6 else PP_ALIGN.LEFT, bg_color=COLOR_BLUE)

    seg_rows = [
        ["High-Friction Starters", "7 (46.7%)", "Month-to-Month", "$409.93 / mo", "7.0 mo", "100.0%", 
         "Early-stage monthly customers facing high ticket friction (avg 4.3) who churned before month 15."],
        ["Mid-Tenure Stabilizers", "4 (26.7%)", "One Year", "$259.96 / mo", "19.8 mo", "0.0%", 
         "Established annual subscribers with moderate support needs nearing their annual contract renewal."],
        ["Enterprise Anchors", "4 (26.7%)", "Two Year", "$599.96 / mo", "38.5 mo", "0.0%", 
         "High-value enterprise accounts on two-year commitments with zero churn and high revenue stability."]
    ]

    for row_idx, r in enumerate(seg_rows, 1):
        bg = COLOR_WHITE if row_idx % 2 == 1 else COLOR_BG_LIGHT
        for col_idx, val in enumerate(r):
            c_color = COLOR_VERMILION if val == "100.0%" else (COLOR_GREEN if val == "0.0%" else COLOR_TEXT_DARK)
            bld = col_idx in [0, 3, 5]
            format_cell(table.cell(row_idx, col_idx), val, font_size=12, bold=bld, 
                        color=c_color, align=PP_ALIGN.CENTER if 0 < col_idx < 6 else PP_ALIGN.LEFT, bg_color=bg)

    add_source_line(slide6)

    # =========================================================
    # SLIDE 7: CHURN-RISK SCORE & PRIORITY LIST
    # =========================================================
    slide7 = prs.slides.add_slide(blank_layout)
    add_header(slide7, "Churn-Risk Score & Priority Triage", 
               "An explainable point system identifies top at-risk active accounts for immediate outreach.")

    # Left Column: Model Rule & Tier Summary
    add_card(slide7, Inches(0.8), Inches(1.8), Inches(4.5), Inches(4.8), COLOR_BG_LIGHT)
    m_box = slide7.shapes.add_textbox(Inches(0.95), Inches(1.95), Inches(4.2), Inches(4.5))
    tf_m = m_box.text_frame
    tf_m.word_wrap = True

    p = tf_m.paragraphs[0]
    p.text = "HOW THE SCORE WORKS (0–5 pts)"
    p.font.size = Pt(15)
    p.font.bold = True
    p.font.color.rgb = COLOR_BLUE

    p_rule = tf_m.add_paragraph()
    p_rule.space_before = Pt(8)
    p_rule.text = "Additive penalty points for contract flexibility (+2 monthly, +1 annual), high support friction (+2 for ≥4 tickets, +1 for 2–3), and early tenure (+1 for ≤6 mo, +0.5 for 7–12 mo)."
    p_rule.font.size = Pt(13)
    p_rule.font.color.rgb = COLOR_TEXT_DARK

    p_tiers = tf_m.add_paragraph()
    p_tiers.space_before = Pt(12)
    p_tiers.text = "RISK TIERS & SEPARATION:"
    p_tiers.font.size = Pt(14)
    p_tiers.font.bold = True
    p_tiers.font.color.rgb = COLOR_TEXT_DARK

    tiers_desc = [
        ("High Risk (≥4.0):", " 5 accounts, 100% churned ($0 active)"),
        ("Medium Risk (2.0–3.5):", " 4 accounts, 2 churned, 2 active ($129.98/mo active exposure)"),
        ("Low Risk (<2.0):", " 6 accounts, 0% churned (all 6 active)")
    ]
    for t_title, t_desc in tiers_desc:
        pt = tf_m.add_paragraph()
        pt.space_before = Pt(6)
        r1 = pt.add_run()
        r1.text = "• " + t_title
        r1.font.bold = True
        r1.font.size = Pt(12)
        r1.font.color.rgb = COLOR_VERMILION if "High" in t_title else (COLOR_ORANGE if "Medium" in t_title else COLOR_GREEN)
        r2 = pt.add_run()
        r2.text = t_desc
        r2.font.size = Pt(12)
        r2.font.color.rgb = COLOR_TEXT_MUTED

    # Right Column: Priority Table of Active Accounts
    t_shape = slide7.shapes.add_table(5, 6, Inches(5.5), Inches(1.8), Inches(7.033), Inches(4.8))
    table = t_shape.table
    table.columns[0].width = Inches(1.2)
    table.columns[1].width = Inches(1.2)
    table.columns[2].width = Inches(1.1)
    table.columns[3].width = Inches(1.2)
    table.columns[4].width = Inches(1.1)
    table.columns[5].width = Inches(1.233)

    headers = ["Priority", "Customer", "Contract", "Monthly Rev", "Score", "Risk Tier"]
    for col_idx, h in enumerate(headers):
        format_cell(table.cell(0, col_idx), h, font_size=13, bold=True, color=COLOR_WHITE, 
                    align=PP_ALIGN.CENTER, bg_color=COLOR_BLUE)

    active_p_data = [
        ["Priority 1", "CUST-1009", "One Year", "$79.99 / mo", "2.0 pts", "Medium Risk"],
        ["Priority 2", "CUST-1006", "One Year", "$49.99 / mo", "2.0 pts", "Medium Risk"],
        ["Priority 3", "CUST-1002", "One Year", "$79.99 / mo", "1.0 pt", "Low Risk"],
        ["Priority 4", "CUST-1013", "One Year", "$49.99 / mo", "1.0 pt", "Low Risk"]
    ]
    for row_idx, r in enumerate(active_p_data, 1):
        bg = COLOR_ACCENT_BG if "Medium" in r[5] else COLOR_WHITE
        for col_idx, val in enumerate(r):
            c_color = COLOR_ORANGE if "Medium" in val else (COLOR_GREEN if "Low" in val else COLOR_TEXT_DARK)
            bld = col_idx in [0, 1, 3, 5]
            format_cell(table.cell(row_idx, col_idx), val, font_size=13, bold=bld, 
                        color=c_color, align=PP_ALIGN.CENTER, bg_color=bg)

    add_source_line(slide7)

    # =========================================================
    # SLIDE 8: STRATEGIC RECOMMENDATIONS (Owner & Timeline)
    # =========================================================
    slide8 = prs.slides.add_slide(blank_layout)
    add_header(slide8, "Prioritized Strategic Recommendations", 
               "Three sequenced interventions address friction removal, contract renewal, and account protection.")

    card_h = Inches(1.5)
    rec_cards = [
        {
            "num": "ACTION 1: ONBOARDING SUPPORT TRIAGE & DEFLECTION",
            "meta": "Target: High-Friction Starters  |  Owner: Customer Success Lead  |  Timeline: Days 1–30",
            "body": "Trigger proactive outreach within 24 hours whenever an onboarding subscriber submits 2+ support tickets. Eliminate technical blockers before customers reach cancellation frustration.",
            "color": COLOR_VERMILION,
            "top": Inches(1.8)
        },
        {
            "num": "ACTION 2: PROACTIVE ANNUAL MIGRATION & RENEWAL INCENTIVES",
            "meta": "Target: Mid-Tenure Stabilizers (CUST-1009 & CUST-1006)  |  Owner: Growth Lead  |  Timeline: Days 30–60",
            "body": "Offer a 15% discount incentive for annual re-commitment 60 days before contract expiration, paired with dedicated account reviews to resolve residual support tickets.",
            "color": COLOR_ORANGE,
            "top": Inches(3.45)
        },
        {
            "num": "ACTION 3: DEDICATED ENTERPRISE EXECUTIVE VALUE REVIEWS",
            "meta": "Target: Enterprise Anchors (4 accounts, $599.96/mo)  |  Owner: Head of Account Mgmt  |  Timeline: Days 60–90",
            "body": "Institute semi-annual Executive Business Reviews and assign dedicated Technical Account Managers to safeguard the enterprise foundation and secure multi-year renewals early.",
            "color": COLOR_GREEN,
            "top": Inches(5.1)
        }
    ]

    for rc in rec_cards:
        add_card(slide8, Inches(0.8), rc['top'], Inches(11.733), card_h, COLOR_BG_LIGHT, rc['color'])
        box = slide8.shapes.add_textbox(Inches(1.0), rc['top'] + Inches(0.1), Inches(11.333), card_h - Inches(0.2))
        tf = box.text_frame
        tf.word_wrap = True
        
        p1 = tf.paragraphs[0]
        p1.text = rc['num']
        p1.font.size = Pt(14)
        p1.font.bold = True
        p1.font.color.rgb = rc['color']

        p2 = tf.add_paragraph()
        p2.text = rc['meta']
        p2.font.size = Pt(12)
        p2.font.bold = True
        p2.font.color.rgb = COLOR_TEXT_DARK
        p2.space_before = Pt(2)

        p3 = tf.add_paragraph()
        p3.text = rc['body']
        p3.font.size = Pt(12.5)
        p3.font.color.rgb = COLOR_TEXT_MUTED
        p3.space_before = Pt(3)

    add_source_line(slide8)

    # =========================================================
    # SLIDE 9: EXPECTED IMPACT (Scenario Modeling)
    # =========================================================
    slide9 = prs.slides.add_slide(blank_layout)
    add_header(slide9, "Expected Financial Impact & Scenarios", 
               "Targeted retention interventions preserve an estimated $60 to $229 in monthly revenue.")

    # Left: Impact Chart
    c_img = slide9.shapes.add_picture('presentation/figures/fig6_impact_scenarios.png', Inches(0.8), Inches(1.8), width=Inches(5.7))
    set_alt_text(c_img, "Stacked bar chart showing monthly retained revenue across Conservative ($60.49/mo), Base ($141.48/mo), and Optimistic ($228.96/mo) scenarios.")

    # Right Top: Scenario Table
    t_shape = slide9.shapes.add_table(4, 4, Inches(6.7), Inches(1.8), Inches(5.833), Inches(2.7))
    table = t_shape.table
    table.columns[0].width = Inches(1.6)
    table.columns[1].width = Inches(1.4)
    table.columns[2].width = Inches(1.4)
    table.columns[3].width = Inches(1.433)

    headers = ["Scenario", "Active Lift", "Monthly Saved", "Annual Value"]
    for col_idx, h in enumerate(headers):
        format_cell(table.cell(0, col_idx), h, font_size=13, bold=True, color=COLOR_WHITE, 
                    align=PP_ALIGN.CENTER if col_idx > 0 else PP_ALIGN.LEFT, bg_color=COLOR_BLUE)

    scen_rows = [
        ["Conservative", "15% lift", "$60.49 / mo", "$725.88 / yr"],
        ["Base Case", "30% lift", "$141.48 / mo", "$1,697.72 / yr"],
        ["Optimistic", "50% lift", "$228.96 / mo", "$2,747.54 / yr"]
    ]
    for row_idx, r in enumerate(scen_rows, 1):
        bg = COLOR_ACCENT_BG if row_idx == 2 else COLOR_WHITE
        for col_idx, val in enumerate(r):
            bld = col_idx in [0, 2, 3]
            c_color = COLOR_GREEN if col_idx >= 2 else COLOR_TEXT_DARK
            format_cell(table.cell(row_idx, col_idx), val, font_size=12.5, bold=bld, 
                        color=c_color, align=PP_ALIGN.CENTER if col_idx > 0 else PP_ALIGN.LEFT, bg_color=bg)

    # Right Bottom: Assumptions Card (Explicitly marked)
    add_card(slide9, Inches(6.7), Inches(4.7), Inches(5.833), Inches(1.9), COLOR_BG_LIGHT, COLOR_ORANGE)
    a_box = slide9.shapes.add_textbox(Inches(6.85), Inches(4.8), Inches(5.533), Inches(1.7))
    tf_a = a_box.text_frame
    tf_a.word_wrap = True

    p = tf_a.paragraphs[0]
    p.text = "MODEL ASSUMPTIONS (Not Forecasts or Guarantees):"
    p.font.size = Pt(13)
    p.font.bold = True
    p.font.color.rgb = COLOR_VERMILION

    assumptions = [
        "1. Active at-risk base: $129.98/mo across Medium-Risk accounts CUST-1009 & CUST-1006.",
        "2. Inflow churn prevention base: $409.93/mo historical early-tenure monthly churn.",
        "3. Formula: Retained Revenue = Base Exposure × Modeled Retention Lift %."
    ]
    for asm in assumptions:
        p = tf_a.add_paragraph()
        p.space_before = Pt(3)
        p.text = asm
        p.font.size = Pt(11.5)
        p.font.color.rgb = COLOR_TEXT_DARK

    add_source_line(slide9, "Source: Modeled transparently from customer_churn_clean.csv (n = 15). All scenarios are illustrative.")

    # =========================================================
    # SLIDE 10: LIMITATIONS & NEXT STEPS
    # =========================================================
    slide10 = prs.slides.add_slide(blank_layout)
    add_header(slide10, "Methodological Limitations & Next Steps", 
               "Small-sample findings provide operational hypotheses requiring controlled A/B testing.")

    col_w = Inches(5.7)
    # Left Card: Limitations
    add_card(slide10, Inches(0.8), Inches(1.8), col_w, Inches(4.9), COLOR_BG_LIGHT, COLOR_CARD_BORDER)
    l_box = slide10.shapes.add_textbox(Inches(1.0), Inches(1.95), Inches(5.3), Inches(4.6))
    tf_l = l_box.text_frame
    tf_l.word_wrap = True

    p = tf_l.paragraphs[0]
    p.text = "ANALYTICAL LIMITATIONS"
    p.font.size = Pt(16)
    p.font.bold = True
    p.font.color.rgb = COLOR_VERMILION

    limits = [
        ("Small Sample Size (n = 15):", " Patterns are directional benchmarks; no statistical inference or p-values are valid."),
        ("No Time Dimension:", " Lacks cancellation timestamps; cannot model hazard rates or seasonal cohort effects."),
        ("In-Sample Calibration:", " Risk weights evaluated on the sample that generated them; risks overfitting."),
        ("No Causal Claims:", " Correlations indicate association, not causation; offers may have variable elasticity.")
    ]
    for title, desc in limits:
        p = tf_l.add_paragraph()
        p.space_before = Pt(10)
        r1 = p.add_run()
        r1.text = "• " + title
        r1.font.bold = True
        r1.font.size = Pt(13)
        r1.font.color.rgb = COLOR_TEXT_DARK
        r2 = p.add_run()
        r2.text = desc
        r2.font.size = Pt(13)
        r2.font.color.rgb = COLOR_TEXT_MUTED

    # Right Card: Next Steps
    add_card(slide10, Inches(6.8), Inches(1.8), col_w, Inches(4.9), COLOR_BG_LIGHT, COLOR_CARD_BORDER)
    n_box = slide10.shapes.add_textbox(Inches(7.0), Inches(1.95), Inches(5.3), Inches(4.6))
    tf_n = n_box.text_frame
    tf_n.word_wrap = True

    p = tf_n.paragraphs[0]
    p.text = "ACTIONABLE NEXT STEPS"
    p.font.size = Pt(16)
    p.font.bold = True
    p.font.color.rgb = COLOR_GREEN

    steps = [
        ("Conduct Live A/B Experiment:", " Test the 15% annual migration discount on incoming monthly users to measure net incremental lift."),
        ("Expand Data Infrastructure:", " Collect telemetry (login frequency, NPS, time-to-resolution) across 250–500 live customer accounts."),
        ("Account for Concession Costs:", " Model the net margin impact of discount offers against long-term customer lifetime value."),
        ("Automate CRM Risk Scoring:", " Ingest rule-based scores into customer success workflows to trigger automated triage.")
    ]
    for title, desc in steps:
        p = tf_n.add_paragraph()
        p.space_before = Pt(10)
        r1 = p.add_run()
        r1.text = "• " + title
        r1.font.bold = True
        r1.font.size = Pt(13)
        r1.font.color.rgb = COLOR_TEXT_DARK
        r2 = p.add_run()
        r2.text = desc
        r2.font.size = Pt(13)
        r2.font.color.rgb = COLOR_TEXT_MUTED

    add_source_line(slide10)

    # Save PPTX
    pptx_path = 'presentation/churn_executive_deck.pptx'
    prs.save(pptx_path)
    print(f"Successfully generated PPTX: {pptx_path}")

    # Export PDF
    export_pdf(pptx_path, 'presentation/churn_executive_deck.pdf')

# -------------------------------------------------------------
# PDF EXPORT FUNCTION (PowerPoint COM with ReportLab fallback)
# -------------------------------------------------------------
def export_pdf(pptx_path, pdf_path):
    abs_pptx = os.path.abspath(pptx_path)
    abs_pdf = os.path.abspath(pdf_path)

    # 1. Try PowerPoint COM (native fidelity)
    try:
        import win32com.client
        ppt_app = win32com.client.Dispatch('PowerPoint.Application')
        presentation = ppt_app.Presentations.Open(abs_pptx, WithWindow=False)
        # 32 = ppSaveAsPDF
        presentation.SaveAs(abs_pdf, 32)
        presentation.Close()
        ppt_app.Quit()
        print(f"Successfully exported PDF using native PowerPoint COM: {pdf_path}")
        return True
    except Exception as e:
        print(f"PowerPoint COM export not available ({e}). Using standalone high-fidelity ReportLab renderer...")

    # 2. Standalone ReportLab Renderer (16:9 Landscape PDF)
    try:
        from reportlab.lib.pagesizes import landscape
        from reportlab.lib.units import inch
        from reportlab.pdfgen import canvas
        from reportlab.lib.colors import HexColor

        page_w = 13.333 * inch
        page_h = 7.5 * inch
        c = canvas.Canvas(abs_pdf, pagesize=(page_w, page_h))

        def draw_slide_base(c, title, takeaway):
            # Background
            c.setFillColor(HexColor('#FFFFFF'))
            c.rect(0, 0, page_w, page_h, fill=1, stroke=0)
            # Header
            c.setFillColor(HexColor('#2B2B2B'))
            c.setFont("Helvetica-Bold", 24)
            c.drawString(0.8 * inch, page_h - 0.7 * inch, title)
            c.setFillColor(HexColor('#0072B2'))
            c.setFont("Helvetica-Bold", 15)
            c.drawString(0.8 * inch, page_h - 1.05 * inch, takeaway)
            # Footer
            c.setFillColor(HexColor('#7F7F7F'))
            c.setFont("Helvetica-Oblique", 10)
            c.drawString(0.8 * inch, 0.4 * inch, "Source: customer_churn_sample.csv, n = 15 (illustrative synthetic sample)")

        # Slide 1: Title
        c.setFillColor(HexColor('#F8F9FA'))
        c.setStrokeColor(HexColor('#0072B2'))
        c.setLineWidth(2)
        c.roundRect(0.8*inch, 0.8*inch, 11.733*inch, 5.9*inch, 10, fill=1, stroke=1)
        c.setFillColor(HexColor('#2B2B2B'))
        c.setFont("Helvetica-Bold", 32)
        c.drawString(1.4*inch, page_h - 1.8*inch, "Customer Churn Analysis & Retention Strategy")
        c.setFillColor(HexColor('#0072B2'))
        c.setFont("Helvetica-Bold", 18)
        c.drawString(1.4*inch, page_h - 2.2*inch, "Executive Analytics Capstone — Priority Roadmap")
        # Decision Question
        c.setFillColor(HexColor('#EDF4FB'))
        c.setStrokeColor(HexColor('#0072B2'))
        c.roundRect(1.4*inch, page_h - 4.2*inch, 10.5*inch, 1.6*inch, 8, fill=1, stroke=1)
        c.setFillColor(HexColor('#0072B2'))
        c.setFont("Helvetica-Bold", 13)
        c.drawString(1.7*inch, page_h - 3.1*inch, "EXECUTIVE DECISION QUESTION:")
        c.setFillColor(HexColor('#2B2B2B'))
        c.setFont("Helvetica-Bold", 19)
        c.drawString(1.7*inch, page_h - 3.6*inch, "“Which customers are most likely to churn, and what should we do first?”")
        c.setFillColor(HexColor('#5F6973'))
        c.setFont("Helvetica", 13)
        c.drawString(1.4*inch, page_h - 5.0*inch, "Senior Data Analyst  |  Executive Briefing  |  customer_churn_clean.csv (n = 15)")
        c.showPage()

        # Slide 2: Executive Summary
        draw_slide_base(c, "Executive Summary", "Three key findings explain churn and anchor our 90-day retention roadmap.")
        # Left card
        c.setFillColor(HexColor('#F8F9FA'))
        c.setStrokeColor(HexColor('#D2D7DC'))
        c.roundRect(0.8*inch, 1.4*inch, 5.7*inch, 4.8*inch, 8, fill=1, stroke=1)
        c.setFillColor(HexColor('#D55E00'))
        c.setFont("Helvetica-Bold", 15)
        c.drawString(1.1*inch, 5.8*inch, "3 KEY FINDINGS (Audited Data)")
        c.setFont("Helvetica", 12.5)
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(1.1*inch, 5.2*inch, "• 46.7% Churn Rate ($409.93/mo Lost):")
        c.setFillColor(HexColor('#5F6973'))
        c.drawString(1.3*inch, 4.9*inch, "7 of 15 customers churned (32.3% of total portfolio MRR).")
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(1.1*inch, 4.2*inch, "• 100% Churn in Month-to-Month Contracts:")
        c.setFillColor(HexColor('#5F6973'))
        c.drawString(1.3*inch, 3.9*inch, "All 7 churned accounts were monthly users averaging 4.3 tickets.")
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(1.1*inch, 3.2*inch, "• $129.98/mo Active Medium-Risk Exposure:")
        c.setFillColor(HexColor('#5F6973'))
        c.drawString(1.3*inch, 2.9*inch, "2 active accounts (CUST-1009, 1006) face renewal ticket friction.")
        # Right card
        c.setFillColor(HexColor('#F8F9FA'))
        c.roundRect(6.8*inch, 1.4*inch, 5.7*inch, 4.8*inch, 8, fill=1, stroke=1)
        c.setFillColor(HexColor('#009E73'))
        c.setFont("Helvetica-Bold", 15)
        c.drawString(7.1*inch, 5.8*inch, "3 PRIORITIZED ACTIONS (90 Days)")
        c.setFont("Helvetica", 12.5)
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(7.1*inch, 5.2*inch, "• Days 1–30: Support Triage (CS Lead):")
        c.setFillColor(HexColor('#5F6973'))
        c.drawString(7.3*inch, 4.9*inch, "Outreach within 24h when tickets ≥ 2 to defuse onboarding friction.")
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(7.1*inch, 4.2*inch, "• Days 30–60: 15% Annual Discount (Sales):")
        c.setFillColor(HexColor('#5F6973'))
        c.drawString(7.3*inch, 3.9*inch, "Migrate accounts CUST-1009 & CUST-1006 to annual contracts.")
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(7.1*inch, 3.2*inch, "• Days 60–90: Enterprise QBRs (Account Mgmt):")
        c.setFillColor(HexColor('#5F6973'))
        c.drawString(7.3*inch, 2.9*inch, "Quarterly executive reviews to protect $599.96/mo enterprise base.")
        c.showPage()

        # Slide 3: Data & Method
        draw_slide_base(c, "Data & Methodology Overview", "Audited synthetic dataset establishing transparent, explainable decision rules.")
        w_col = 3.64*inch
        # 3 Cards
        for i, (t_title, t_col, items) in enumerate([
            ("1. DATASET PROFILE", HexColor('#0072B2'), [
                ("Source:", "customer_churn_sample.csv"),
                ("Dimensions:", "15 records × 11 fields"),
                ("Clean Table:", "12 fields (+Churn_Flag)"),
                ("Quality Check:", "0 nulls, 0 duplicates"),
                ("Completeness:", "100% verified complete")
            ]),
            ("2. CLEANING CHECKS", HexColor('#0072B2'), [
                ("Type Assertion:", "Strict int & float types"),
                ("String Trimming:", "Whitespace stripped"),
                ("Charge Formula:", "Total ≈ Monthly × Tenure"),
                ("Tolerance Pass:", "15 of 15 pass (±$0.05)"),
                ("Validation Suite:", "12 of 12 tests passed")
            ]),
            ("3. METHOD & CAVEAT", HexColor('#E69F00'), [
                ("Analysis Mode:", "Transparent rules, no black boxes"),
                ("Scoring Logic:", "0–5 point additive model"),
                ("Small Sample:", "n = 15 synthetic records"),
                ("Interpretation:", "Illustrative operational patterns"),
                ("No Causality:", "Benchmarks, not proven proofs")
            ])
        ]):
            x = (0.8 + i*4.04)*inch
            c.setFillColor(HexColor('#F8F9FA') if i < 2 else HexColor('#EDF4FB'))
            c.setStrokeColor(HexColor('#D2D7DC') if i < 2 else HexColor('#E69F00'))
            c.roundRect(x, 1.4*inch, w_col, 4.8*inch, 8, fill=1, stroke=1)
            c.setFillColor(t_col)
            c.setFont("Helvetica-Bold", 14)
            c.drawString(x + 0.2*inch, 5.8*inch, t_title)
            c.setFont("Helvetica", 12)
            y_item = 5.2*inch
            for k, v in items:
                c.setFillColor(HexColor('#2B2B2B'))
                c.drawString(x + 0.2*inch, y_item, f"{k} {v}")
                y_item -= 0.65*inch
        c.showPage()

        # Slide 4: Headline KPIs
        draw_slide_base(c, "Portfolio Headline KPIs", "High monthly churn contrasts sharply with long-term enterprise retention stability.")
        if os.path.exists('presentation/figures/fig4_kpi_cards.png'):
            c.drawImage('presentation/figures/fig4_kpi_cards.png', 0.8*inch, 3.4*inch, width=11.733*inch, height=2.8*inch)
        # Summary Box
        c.setFillColor(HexColor('#F8F9FA'))
        c.setStrokeColor(HexColor('#D2D7DC'))
        c.roundRect(0.8*inch, 1.4*inch, 11.733*inch, 1.8*inch, 8, fill=1, stroke=1)
        c.setFillColor(HexColor('#2B2B2B'))
        c.setFont("Helvetica-Bold", 13)
        c.drawString(1.1*inch, 2.8*inch, "PORTFOLIO CHURN VS. RETENTION BREAKDOWN:")
        c.setFont("Helvetica", 12)
        c.drawString(1.1*inch, 2.4*inch, "• Total Portfolio: 15 accounts  |  $1,269.85/mo MRR  |  Avg Tenure: 18.80 months  |  Avg Tickets: 2.53")
        c.setFillColor(HexColor('#D55E00'))
        c.drawString(1.1*inch, 2.0*inch, "• Churned Cohort: 7 accounts (46.7%)  |  $409.93/mo Lost (32.3% of MRR)  |  Avg Tenure: 7.00 months  |  Avg Tickets: 4.29")
        c.setFillColor(HexColor('#009E73'))
        c.drawString(1.1*inch, 1.6*inch, "• Retained Cohort: 8 accounts (53.3%)  |  $859.92/mo Active  |  Avg Tenure: 29.13 months  |  Avg Tickets: 1.00")
        c.showPage()

        # Slide 5: Drivers of Churn
        draw_slide_base(c, "Primary Churn Drivers", "Month-to-month contracts and early technical friction drive customer cancellation.")
        img_w = 3.75*inch
        img_h = 2.4*inch
        if os.path.exists('presentation/figures/fig1_contract_churn.png'):
            c.drawImage('presentation/figures/fig1_contract_churn.png', 0.8*inch, 3.4*inch, width=img_w, height=img_h)
        if os.path.exists('presentation/figures/fig2_tenure_churn.png'):
            c.drawImage('presentation/figures/fig2_tenure_churn.png', 4.79*inch, 3.4*inch, width=img_w, height=img_h)
        if os.path.exists('presentation/figures/fig3_tickets_churn.png'):
            c.drawImage('presentation/figures/fig3_tickets_churn.png', 8.78*inch, 3.4*inch, width=img_w, height=img_h)
        c.setFillColor(HexColor('#EDF4FB'))
        c.setStrokeColor(HexColor('#0072B2'))
        c.roundRect(0.8*inch, 1.4*inch, 11.733*inch, 1.6*inch, 8, fill=1, stroke=1)
        c.setFillColor(HexColor('#2B2B2B'))
        c.setFont("Helvetica-Bold", 14)
        c.drawString(1.1*inch, 2.5*inch, "Operational Takeaway:")
        c.setFont("Helvetica", 13)
        c.drawString(1.1*inch, 2.1*inch, "Customers on flexible month-to-month contracts who submit 3 or more support tickets within their first")
        c.drawString(1.1*inch, 1.75*inch, "12 months represent acute cancellation risk and require mandatory same-day intervention.")
        c.showPage()

        # Slide 6: Customer Segments
        draw_slide_base(c, "Customer Behavioral Segments", "Three behavioral cohorts require distinct operational retention strategies.")
        # Segment cards
        for i, (s_name, s_meta, s_story, s_col) in enumerate([
            ("High-Friction Starters (7 accounts | 46.7%)", "Contract: Month-to-Month  |  Revenue: $409.93/mo  |  Avg Tenure: 7.0 mo  |  Churn: 100.0%",
             "Early-stage monthly customers facing high ticket friction (avg 4.29) who churned before month 15.", HexColor('#D55E00')),
            ("Mid-Tenure Stabilizers (4 accounts | 26.7%)", "Contract: One Year  |  Revenue: $259.96/mo  |  Avg Tenure: 19.8 mo  |  Churn: 0.0%",
             "Established annual subscribers with moderate support needs nearing their annual contract renewal.", HexColor('#E69F00')),
            ("Enterprise Anchors (4 accounts | 26.7%)", "Contract: Two Year  |  Revenue: $599.96/mo  |  Avg Tenure: 38.5 mo  |  Churn: 0.0%",
             "High-value enterprise accounts on two-year commitments with zero churn and high revenue stability.", HexColor('#009E73'))
        ]):
            y_card = (4.5 - i*1.55)*inch
            c.setFillColor(HexColor('#F8F9FA'))
            c.setStrokeColor(s_col)
            c.setLineWidth(1.5)
            c.roundRect(0.8*inch, y_card, 11.733*inch, 1.35*inch, 6, fill=1, stroke=1)
            c.setFillColor(s_col)
            c.setFont("Helvetica-Bold", 13.5)
            c.drawString(1.1*inch, y_card + 0.95*inch, s_name)
            c.setFillColor(HexColor('#2B2B2B'))
            c.setFont("Helvetica-Bold", 11.5)
            c.drawString(1.1*inch, y_card + 0.65*inch, s_meta)
            c.setFillColor(HexColor('#5F6973'))
            c.setFont("Helvetica", 11.5)
            c.drawString(1.1*inch, y_card + 0.3*inch, f"Story: {s_story}")
        c.showPage()

        # Slide 7: Churn Risk Score & Priority
        draw_slide_base(c, "Churn-Risk Score & Priority Triage", "An explainable point system identifies top at-risk active accounts for immediate outreach.")
        # Left card
        c.setFillColor(HexColor('#F8F9FA'))
        c.setStrokeColor(HexColor('#D2D7DC'))
        c.roundRect(0.8*inch, 1.4*inch, 4.8*inch, 4.8*inch, 8, fill=1, stroke=1)
        c.setFillColor(HexColor('#0072B2'))
        c.setFont("Helvetica-Bold", 14)
        c.drawString(1.0*inch, 5.8*inch, "SCORING MODEL (0–5 Points)")
        c.setFont("Helvetica", 12)
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(1.0*inch, 5.2*inch, "Points assigned transparently for:")
        c.drawString(1.0*inch, 4.85*inch, "• Contract: +2 Month-to-Month, +1 Annual, 0 Two-Year")
        c.drawString(1.0*inch, 4.5*inch, "• Tickets: +2 for ≥4 tickets, +1 for 2–3 tickets")
        c.drawString(1.0*inch, 4.15*inch, "• Tenure: +1 for ≤6 months, +0.5 for 7–12 months")
        c.setFillColor(HexColor('#D55E00'))
        c.drawString(1.0*inch, 3.4*inch, "• High Risk (≥4.0): 5 accts (100% churned)")
        c.setFillColor(HexColor('#E69F00'))
        c.drawString(1.0*inch, 2.9*inch, "• Medium Risk (2.0–3.5): 4 accts (2 churn, 2 active)")
        c.setFillColor(HexColor('#009E73'))
        c.drawString(1.0*inch, 2.4*inch, "• Low Risk (<2.0): 6 accts (0% churned, all active)")
        # Right card: Priority table
        c.setFillColor(HexColor('#F8F9FA'))
        c.roundRect(5.8*inch, 1.4*inch, 6.733*inch, 4.8*inch, 8, fill=1, stroke=1)
        c.setFillColor(HexColor('#0072B2'))
        c.setFont("Helvetica-Bold", 14)
        c.drawString(6.0*inch, 5.8*inch, "TOP AT-RISK ACTIVE CUSTOMERS (Immediate Triage)")
        c.setFont("Helvetica", 12)
        c.setFillColor(HexColor('#E69F00'))
        c.drawString(6.0*inch, 5.1*inch, "Priority 1: CUST-1009 ($79.99/mo) — Medium Risk (2.0 pts)")
        c.setFillColor(HexColor('#5F6973'))
        c.drawString(6.2*inch, 4.75*inch, "Pro tier, One-Year contract, 15 mo tenure, 2 unresolved tickets.")
        c.setFillColor(HexColor('#E69F00'))
        c.drawString(6.0*inch, 4.0*inch, "Priority 2: CUST-1006 ($49.99/mo) — Medium Risk (2.0 pts)")
        c.setFillColor(HexColor('#5F6973'))
        c.drawString(6.2*inch, 3.65*inch, "Basic tier, One-Year contract, 18 mo tenure, 2 unresolved tickets.")
        c.setFillColor(HexColor('#009E73'))
        c.drawString(6.0*inch, 2.9*inch, "Priorities 3–4: CUST-1002 & CUST-1013 — Low Risk (1.0 pt)")
        c.setFillColor(HexColor('#5F6973'))
        c.drawString(6.2*inch, 2.55*inch, "Annual subscribers, 1 ticket; routine renewal outreach.")
        c.showPage()

        # Slide 8: Strategic Recommendations
        draw_slide_base(c, "Prioritized Strategic Recommendations", "Three sequenced interventions address friction removal, contract renewal, and account protection.")
        for i, (action_t, owner_t, body_t, a_col) in enumerate([
            ("ACTION 1: ONBOARDING SUPPORT TRIAGE & DEFLECTION", "Target: High-Friction Starters  |  Owner: Customer Success Lead  |  Days 1–30",
             "Proactive outreach within 24 hours when new users log 2+ tickets to resolve technical friction early.", HexColor('#D55E00')),
            ("ACTION 2: PROACTIVE ANNUAL MIGRATION INCENTIVES", "Target: Mid-Tenure Stabilizers (CUST-1009, 1006)  |  Owner: Sales Lead  |  Days 30–60",
             "Offer 15% discount for annual contract migration 60 days before expiration, resolving open support issues.", HexColor('#E69F00')),
            ("ACTION 3: DEDICATED ENTERPRISE VALUE REVIEWS", "Target: Enterprise Anchors (4 accounts, $599.96/mo)  |  Owner: Head of Accounts  |  Days 60–90",
             "Conduct semi-annual executive business reviews to secure multi-year commitments and safeguard core revenue.", HexColor('#009E73'))
        ]):
            y_card = (4.5 - i*1.55)*inch
            c.setFillColor(HexColor('#F8F9FA'))
            c.setStrokeColor(a_col)
            c.setLineWidth(1.5)
            c.roundRect(0.8*inch, y_card, 11.733*inch, 1.35*inch, 6, fill=1, stroke=1)
            c.setFillColor(a_col)
            c.setFont("Helvetica-Bold", 13.5)
            c.drawString(1.1*inch, y_card + 0.95*inch, action_t)
            c.setFillColor(HexColor('#2B2B2B'))
            c.setFont("Helvetica-Bold", 11.5)
            c.drawString(1.1*inch, y_card + 0.65*inch, owner_t)
            c.setFillColor(HexColor('#5F6973'))
            c.setFont("Helvetica", 11.5)
            c.drawString(1.1*inch, y_card + 0.3*inch, body_t)
        c.showPage()

        # Slide 9: Expected Impact
        draw_slide_base(c, "Expected Financial Impact & Scenarios", "Targeted retention interventions preserve an estimated $60 to $229 in monthly revenue.")
        if os.path.exists('presentation/figures/fig6_impact_scenarios.png'):
            c.drawImage('presentation/figures/fig6_impact_scenarios.png', 0.8*inch, 1.8*inch, width=5.6*inch, height=3.6*inch)
        # Right side: Table and Assumptions
        c.setFillColor(HexColor('#F8F9FA'))
        c.setStrokeColor(HexColor('#D2D7DC'))
        c.roundRect(6.6*inch, 3.3*inch, 5.933*inch, 2.8*inch, 8, fill=1, stroke=1)
        c.setFillColor(HexColor('#0072B2'))
        c.setFont("Helvetica-Bold", 13.5)
        c.drawString(6.8*inch, 5.75*inch, "MODELED RETENTION SCENARIOS")
        c.setFont("Helvetica", 12)
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(6.8*inch, 5.2*inch, "• Conservative (15% lift):")
        c.setFillColor(HexColor('#009E73'))
        c.drawString(7.0*inch, 4.85*inch, "Saves $60.49 / mo ($725.88 / yr)")
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(6.8*inch, 4.35*inch, "• Base Case (30% lift):")
        c.setFillColor(HexColor('#009E73'))
        c.drawString(7.0*inch, 4.0*inch, "Saves $141.48 / mo ($1,697.72 / yr)")
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(6.8*inch, 3.5*inch, "• Optimistic (50% lift):")
        c.setFillColor(HexColor('#009E73'))
        c.drawString(7.0*inch, 3.15*inch, "Saves $228.96 / mo ($2,747.54 / yr)")
        # Assumptions box
        c.setFillColor(HexColor('#EDF4FB'))
        c.setStrokeColor(HexColor('#D55E00'))
        c.roundRect(6.6*inch, 1.4*inch, 5.933*inch, 1.6*inch, 6, fill=1, stroke=1)
        c.setFillColor(HexColor('#D55E00'))
        c.setFont("Helvetica-Bold", 11.5)
        c.drawString(6.8*inch, 2.65*inch, "MODEL ASSUMPTIONS (Not Forecasts or Guarantees):")
        c.setFont("Helvetica", 10.5)
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(6.8*inch, 2.3*inch, "1. Active at-risk base: $129.98/mo across CUST-1009 and CUST-1006.")
        c.drawString(6.8*inch, 1.95*inch, "2. Prevented inflow churn: $409.93/mo early-stage monthly base.")
        c.drawString(6.8*inch, 1.6*inch, "3. Retained Revenue = Base Exposure × Modeled Lift %.")
        c.showPage()

        # Slide 10: Limitations & Next Steps
        draw_slide_base(c, "Methodological Limitations & Next Steps", "Small-sample findings provide operational hypotheses requiring controlled A/B testing.")
        # Left card
        c.setFillColor(HexColor('#F8F9FA'))
        c.setStrokeColor(HexColor('#D2D7DC'))
        c.roundRect(0.8*inch, 1.4*inch, 5.7*inch, 4.8*inch, 8, fill=1, stroke=1)
        c.setFillColor(HexColor('#D55E00'))
        c.setFont("Helvetica-Bold", 15)
        c.drawString(1.1*inch, 5.8*inch, "ANALYTICAL LIMITATIONS")
        c.setFont("Helvetica", 12.5)
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(1.1*inch, 5.2*inch, "• Small Synthetic Sample (n = 15):")
        c.setFillColor(HexColor('#5F6973'))
        c.drawString(1.3*inch, 4.9*inch, "Findings are illustrative benchmarks; no p-values valid.")
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(1.1*inch, 4.2*inch, "• Absence of Time Dimension:")
        c.setFillColor(HexColor('#5F6973'))
        c.drawString(1.3*inch, 3.9*inch, "No cancellation timestamps; cannot run survival models.")
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(1.1*inch, 3.2*inch, "• In-Sample Calibration & No Causality:")
        c.setFillColor(HexColor('#5F6973'))
        c.drawString(1.3*inch, 2.9*inch, "Scores calibrated on same records; association only.")
        # Right card
        c.setFillColor(HexColor('#F8F9FA'))
        c.roundRect(6.8*inch, 1.4*inch, 5.7*inch, 4.8*inch, 8, fill=1, stroke=1)
        c.setFillColor(HexColor('#009E73'))
        c.setFont("Helvetica-Bold", 15)
        c.drawString(7.1*inch, 5.8*inch, "ACTIONABLE NEXT STEPS")
        c.setFont("Helvetica", 12.5)
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(7.1*inch, 5.2*inch, "• Controlled A/B Test of Migration Offer:")
        c.setFillColor(HexColor('#5F6973'))
        c.drawString(7.3*inch, 4.9*inch, "Test 15% discount to measure true price elasticity.")
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(7.1*inch, 4.2*inch, "• Expand Telemetry to 250–500 Accounts:")
        c.setFillColor(HexColor('#5F6973'))
        c.drawString(7.3*inch, 3.9*inch, "Ingest login frequency, NPS, and ticket resolution times.")
        c.setFillColor(HexColor('#2B2B2B'))
        c.drawString(7.1*inch, 3.2*inch, "• Model Net Retention Margin:")
        c.setFillColor(HexColor('#5F6973'))
        c.drawString(7.3*inch, 2.9*inch, "Account for concession and staff costs against LTV.")
        c.showPage()

        c.save()
        print(f"Successfully generated standalone PDF with ReportLab: {pdf_path}")
        return True
    except Exception as e:
        print(f"Error in ReportLab export: {e}")
        return False

if __name__ == '__main__':
    build_deck()

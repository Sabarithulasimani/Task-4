# Executive Analytics Capstone: Customer Churn & Retention Strategy

[![Data Pipeline](https://img.shields.io/badge/Pipeline-Verified-009E73.svg)](#qa--numbers-reconciliation)
[![Deck Status](https://img.shields.io/badge/Presentation-10_Slides_Complete-0072B2.svg)](#executive-presentation-deck)
[![Deliverable Compliance](https://img.shields.io/badge/QA_Validation-100%25_Pass-D55E00.svg)](#pass-criteria-checklist)

This repository contains the complete **Executive Analytics Capstone** for customer churn analysis, behavioral customer segmentation, rule-based churn-risk modeling, and executive presentation deliverables. 

Every quantitative figure presented across the capstone deck, memo, and dashboard has been independently verified and audited against the clean dataset using reproducible Python code.

---

## 1. Project Overview & Decision Context

* **Executive Decision Question:** *“Which customers are most likely to churn, and what should we do first?”*
* **Core Findings:**
  1. Historical churn is **46.7%** (7 of 15 accounts), representing **$409.93 / month** in lost recurring revenue (32.3% of portfolio MRR).
  2. Churn is concentrated exclusively in **Month-to-Month contracts (100% churn)** and users experiencing high technical support friction (**average 4.29 tickets** vs. 1.00 for retained).
  3. Two active accounts (**CUST-1009** at $79.99/mo and **CUST-1006** at $49.99/mo) represent **$129.98 / month** in active **Medium-Risk exposure** due to unresolved support tickets and upcoming annual renewals.
* **Strategic Roadmap:** A phased 90-day plan targeting friction triage (Days 1–30), annual migration discounts (Days 30–60), and enterprise executive value reviews (Days 60–90).
* **Expected Impact:** Modeled retention lift preserves an estimated **$60.49 to $228.96 / month** ($726 to $2,748 / year) under transparent, explicitly declared assumptions.

> ⚠️ **Dataset Notice:** All calculations are derived from `customer_churn_sample.csv` ($n = 15$ synthetic sample). Patterns are illustrative benchmarks to establish decision frameworks, not statistically proven population truths.

---

## 2. Deliverables Directory & Repository Map

Every project asset is organized cleanly within this self-contained workspace:

```
Task 4/
├── data/
│   ├── raw/
│   │   └── customer_churn_sample.csv          # Raw synthetic customer churn data (15 rows)
│   └── clean/
│       └── customer_churn_clean.csv           # Cleaned & validated dataset (+Churn_Flag)
├── docs/
│   └── kpi_definitions.md                     # KPI formulas, rules, and edge cases
├── dashboard/
│   └── index.html                             # Interactive Business KPI Dashboard
├── notebooks/
│   ├── 01_data_quality_eda.ipynb              # Task 02: Data Quality Audit & Exploratory Analysis
│   └── 02_segmentation_recommendation.ipynb   # Task 04: Customer Segmentation & Risk Scoring Model
├── outputs/
│   ├── segment_table.csv                      # Segment metrics, revenue share, and narratives
│   ├── customer_risk_scores.csv               # Customer-level point breakdown & priority triage
│   └── numbers_reconciliation.csv             # 30-point QA verification audit table
├── reports/
│   ├── data_quality_summary.md                # 12-point data quality & cleaning audit report
│   ├── recommendation_memo.md                 # Strategic recommendation memo for executive leadership
│   └── numbers_reconciliation.md              # Markdown audit trail reconciling all slide numbers
├── presentation/
│   ├── build_deck.py                          # Master single-script generator (builds PPTX & exports PDF)
│   ├── churn_executive_deck.pptx              # 10-slide executive presentation (python-pptx)
│   ├── churn_executive_deck.pdf               # High-fidelity vector PDF export
│   ├── speaker_notes.md                       # Structured speaker notes (2-4 sentences per slide)
│   └── figures/                               # Okabe-Ito colorblind-safe analytical figures
│       ├── fig1_contract_churn.png            # Churn rate by contract type
│       ├── fig2_tenure_churn.png              # Churn rate by customer tenure band
│       ├── fig3_tickets_churn.png             # Average support tickets by churn status
│       ├── fig4_kpi_cards.png                 # Executive headline KPI summary cards
│       ├── fig5_risk_score_distribution.png   # Customer distribution across risk tiers
│       └── fig6_impact_scenarios.png          # Modeled retained revenue by scenario
├── scripts/
│   ├── build_segmentation.py                  # Generates segment_table.csv & customer_risk_scores.csv
│   ├── build_segmentation_notebook.py         # Builds & formats 02_segmentation_recommendation.ipynb
│   ├── generate_figures.py                    # Generates presentation chart figures
│   ├── verify_reconciliation.py               # Computes numbers reconciliation table
│   └── language_check.py                      # Automated compliance scan for unhedged language
└── README.md                                  # Capstone summary & navigation guide
```

---

## 3. Quick Links to Key Deliverables

* 📊 **Executive Presentation Deck:**
  * [churn_executive_deck.pptx](file:///d:/sabari%20pvt/Sabari%20study/Internship/Task%204/presentation/churn_executive_deck.pptx) — Editable 16:9 widescreen PowerPoint deck.
  * [churn_executive_deck.pdf](file:///d:/sabari%20pvt/Sabari%20study/Internship/Task%204/presentation/churn_executive_deck.pdf) — Exported high-fidelity PDF presentation.
  * [speaker_notes.md](file:///d:/sabari%20pvt/Sabari%20study/Internship/Task%204/presentation/speaker_notes.md) — 2–4 sentences of executive speaking guidance per slide.
* 📝 **Strategic Decision Briefs & Technical Reports:**
  * [recommendation_memo.md](file:///d:/sabari%20pvt/Sabari%20study/Internship/Task%204/reports/recommendation_memo.md) — Comprehensive executive decision memo.
  * [data_quality_summary.md](file:///d:/sabari%20pvt/Sabari%20study/Internship/Task%204/reports/data_quality_summary.md) — 12-point dataset profiling and cleaning audit.
  * [numbers_reconciliation.md](file:///d:/sabari%20pvt/Sabari%20study/Internship/Task%204/reports/numbers_reconciliation.md) — Audit reconciling every deck figure with Pandas.
* 💻 **Interactive Tools & Analysis Notebooks:**
  * [02_segmentation_recommendation.ipynb](file:///d:/sabari%20pvt/Sabari%20study/Internship/Task%204/notebooks/02_segmentation_recommendation.ipynb) — End-to-end segmentation and modeling notebook.
  * [01_data_quality_eda.ipynb](file:///d:/sabari%20pvt/Sabari%20study/Internship/Task%204/notebooks/01_data_quality_eda.ipynb) — Data quality profiling and exploratory data analysis.
  * [dashboard/index.html](file:///d:/sabari%20pvt/Sabari%20study/Internship/Task%204/dashboard/index.html) — Interactive Business KPI Dashboard with live filtering.
  * [docs/kpi_definitions.md](file:///d:/sabari%20pvt/Sabari%20study/Internship/Task%204/docs/kpi_definitions.md) — Rigorous KPI formulas, numerators, and denominators.
* 📁 **Data & Scored Tables:**
  * [segment_table.csv](file:///d:/sabari%20pvt/Sabari%20study/Internship/Task%204/outputs/segment_table.csv) — Segment-level cohort table.
  * [customer_risk_scores.csv](file:///d:/sabari%20pvt/Sabari%20study/Internship/Task%204/outputs/customer_risk_scores.csv) — Customer risk scoring and priority triage ranking.

---

## 4. How to Regenerate the Presentation

The presentation deck and its figures can be regenerated at any time using a single automated script:

```bash
# 1. Regenerate presentation figures (optional, build_deck.py loads these)
python scripts/generate_figures.py

# 2. Build the PowerPoint deck and export the PDF
python presentation/build_deck.py
```

The script `presentation/build_deck.py`:
1. Constructs `presentation/churn_executive_deck.pptx` using `python-pptx`, enforcing strict 16:9 widescreen layout, Okabe-Ito colors, $\ge 18\text{pt}$ body text, action-oriented takeaway headlines, formatted tables, and embedded alt text on all images.
2. Exports `presentation/churn_executive_deck.pdf` directly using native PowerPoint COM (or falls back to an embedded ReportLab vector renderer in headless environments).

---

## 5. Slide-by-Slide Executive Deck Architecture

The presentation strictly adheres to executive communication best practices: one core message per slide, an action headline stating the takeaway, under 30 words of body prose, labeled axes, and direct data callouts.

| Slide # | Slide Title | Action-Style Takeaway Headline | Primary Visual / Table Element | Key Numbers Verified |
|:---:|---|---|---|---|
| **1** | Title & Decision Question | Executive Decision Question: *“Which customers are most likely to churn, and what should we do first?”* | Executive title card with callout question box | $n = 15$ sample |
| **2** | Executive Summary | Three key findings explain churn and anchor our 90-day retention roadmap. | Split-screen comparative cards (Findings vs. Actions) | 46.7% churn, $409.93/mo lost, $129.98 active risk, 30-60-90 days |
| **3** | Data & Methodology | Audited synthetic dataset establishing transparent, explainable decision rules. | 3-card structural overview (Profile, Cleaning, Caveats) | 15 rows, 12 cols, 0 nulls, 0 duplicates, $\pm\$0.05$ pass |
| **4** | Portfolio Headline KPIs | High monthly churn contrasts sharply with long-term enterprise retention stability. | Embedded KPI cards graphic + Cohort comparison table | 46.7% churn, 53.3% retention, $409.93/mo lost, 18.8 mo avg tenure |
| **5** | Primary Churn Drivers | Month-to-month contracts and early technical friction drive customer cancellation. | 3 side-by-side charts: Contract Type, Tenure Band, Support Tickets | 100% monthly churn, 100% 0–12 mo churn, 4.29 churn tickets vs. 1.00 retained |
| **6** | Customer Behavioral Segments | Three behavioral cohorts require distinct operational retention strategies. | Comprehensive Segment Table with one-line narratives | 7 Starters ($409.93), 4 Stabilizers ($259.96), 4 Anchors ($599.96) |
| **7** | Churn-Risk Score & Priority Triage | An explainable point system identifies top at-risk active accounts for immediate outreach. | Model weights explanation card + Active priority ranking table | CUST-1009 ($79.99, Med Risk), CUST-1006 ($49.99, Med Risk) |
| **8** | Strategic Recommendations | Three sequenced interventions address friction removal, contract renewal, and account protection. | 3 sequenced operational action cards with owners and timelines | Action 1 (Days 1–30), Action 2 (Days 30–60), Action 3 (Days 60–90) |
| **9** | Expected Financial Impact | Targeted retention interventions preserve an estimated $60 to $229 in monthly revenue. | Stacked scenario bar chart + Impact table + Explicit Assumptions box | Conservative: $60.49/mo, Base: $141.48/mo, Optimistic: $228.96/mo |
| **10** | Methodological Limitations & Next Steps | Small-sample findings provide operational hypotheses requiring controlled A/B testing. | 2 comparative cards: Analytical Limitations vs. Actionable Next Steps | $n = 15$ sample, pilot cohort: 250–500 live accounts |

---

## 6. QA & Numbers Reconciliation

Every number across all 10 presentation slides was audited using Python and pandas. A sample of the verification table is provided below (see [reports/numbers_reconciliation.md](file:///d:/sabari%20pvt/Sabari%20study/Internship/Task%204/reports/numbers_reconciliation.md) for full audit details):

| Slide # | Metric / Figure | Presentation Value | Exact Source Calculation (Pandas) | Audit Status |
|:---:|---|---|---|:---:|
| **Slide 2** | Overall Churn Rate | **46.7%** | `(df['Churn']=='Yes').mean() * 100` = 46.67% (7/15) | ✅ Verified |
| **Slide 2** | Revenue Lost to Churn | **$409.93 / mo** | `df[df['Churn']=='Yes']['MonthlyCharges'].sum()` = $409.93 | ✅ Verified |
| **Slide 2** | Active Medium-Risk MRR | **$129.98 / mo** | `scores_df[(scores['Churn']=='No') & (scores['RiskTier']=='Medium')]['MonthlyCharges'].sum()` | ✅ Verified |
| **Slide 4** | Retention Rate | **53.3%** | `(df['Churn']=='No').mean() * 100` = 53.33% (8/15) | ✅ Verified |
| **Slide 4** | Average Tenure (Retained vs. Churned) | **29.13 mo vs. 7.00 mo** | `df.groupby('Churn')['TenureMonths'].mean()` = 29.13 vs. 7.00 | ✅ Verified |
| **Slide 5** | Month-to-Month Churn Rate | **100.0%** | `df[df['ContractType']=='Month-to-Month']['Churn_Flag'].mean() * 100` = 100.0% (7/7) | ✅ Verified |
| **Slide 5** | Support Tickets (Churn vs. Retained) | **4.29 vs. 1.00** | `df.groupby('Churn')['SupportTickets'].mean()` = 4.29 vs. 1.00 | ✅ Verified |
| **Slide 6** | Enterprise Anchors Revenue | **$599.96 / mo** | `df[df['ContractType']=='Two Year']['MonthlyCharges'].sum()` = $599.96 (47.2% MRR) | ✅ Verified |
| **Slide 7** | Priority 1 Active Customer | **CUST-1009 ($79.99/mo)** | Pro Tier, One Year, 15 mo, 2 tickets, Risk Score: 2.0 (Medium) | ✅ Verified |
| **Slide 7** | Priority 2 Active Customer | **CUST-1006 ($49.99/mo)** | Basic Tier, One Year, 18 mo, 2 tickets, Risk Score: 2.0 (Medium) | ✅ Verified |
| **Slide 9** | Base Case Retained Revenue | **$141.48 / mo ($1,698/yr)** | `$129.98 * 0.30 + $409.93 * 0.25` = $38.99 + $102.48 = $141.48 | ✅ Verified |

---

## 7. Pass Criteria Compliance Checklist

| Task Requirement / Passing Criterion | Status | Implementing Deliverables & Location |
|---|:---:|---|
| **1. Concise Executive Presentation** | ✅ PASS | 10-slide widescreen presentation (`presentation/churn_executive_deck.pptx` and `.pdf`) with action headlines, $\ge 18\text{pt}$ typography, Okabe-Ito color palette, direct data labels, and no text overflow. |
| **2. Limitations Fully Articulated** | ✅ PASS | Highlighted on Slide 3, Slide 10, in the recommendation memo (§8), and on chart footers: explicitly noting $n=15$ small synthetic sample, cross-sectional design, in-sample calibration, and lack of causal claims. |
| **3. Actionable Strategic Recommendations** | ✅ PASS | Presented on Slide 2, Slide 8, and memo (§6): three sequenced interventions with concrete operational owners, segments, and 30-60-90 day timelines. |
| **4. Expected Impact Modeling** | ✅ PASS | Modeled on Slide 9, memo (§7), and notebook (§7): Conservative (15%), Base (30%), and Optimistic (50%) scenarios computed transparently from clean data with explicit assumption disclaimers. |
| **5. Explainable Churn-Risk Model** | ✅ PASS | Complete 0–5 point additive model documented in `outputs/customer_risk_scores.csv`, validated across boundary edge cases with active customer triage ranking. |
| **6. Reproducible Single-Script Regeneration** | ✅ PASS | `presentation/build_deck.py` builds PPTX and exports PDF automatically with zero manual steps. |
| **7. Language & Claims Compliance** | ✅ PASS | Verified via automated regex scan: zero words like "proves" or "guarantees"; all assertions properly hedged as illustrative operating hypotheses. |

---

## 8. Critical Assumptions to Double-Check Before Submission

Before final submission of your proof link, review these key analytical assumptions:
1. **Active Exposure Definition:** In earlier descriptive KPI reporting (Task 03), revenue at risk evaluated to $\$0.00$ under the strict historical rule because all month-to-month accounts had already churned. Our capstone model identifies **$\$129.98 / \text{month}$** in active risk exposure across Medium-Risk accounts **CUST-1009** and **CUST-1006** based on upcoming annual renewals and unresolved support tickets.
2. **Scenario Base Rates:** Expected impact scenarios model retention lifts applied against active Medium-Risk MRR ($\$129.98/\text{mo}$) and historical monthly churn baseline ($\$409.93/\text{mo}$). These scenarios assume marketing and customer success interventions achieve modeled retention percentages; they are decision-support scenarios, not financial guarantees.
3. **Generalizability Caution:** The dataset consists of 15 synthetic rows. While internal consistency and mathematical reconciliation are 100% verified, live business rollout requires A/B testing on an expanded cohort of 250–500 accounts before committing significant operational budget.

import re

files_to_check = [
    'presentation/build_deck.py',
    'presentation/speaker_notes.md',
    'reports/recommendation_memo.md',
    'reports/numbers_reconciliation.md'
]

forbidden_words = ['prove', 'proves', 'guarantee', 'guarantees', 'guaranteed', 'caused', 'causes']

print('--- LANGUAGE CHECK SCAN ---')
total_flags = 0
for fpath in files_to_check:
    with open(fpath, encoding='utf-8') as f:
        content = f.read()
    
    lines = content.split('\n')
    for line_idx, line in enumerate(lines, 1):
        for word in forbidden_words:
            matches = re.finditer(r'\b' + re.escape(word) + r'\b', line, re.IGNORECASE)
            for m in matches:
                total_flags += 1
                print(f'{fpath}:{line_idx} -> Found "{word}": {line.strip()[:100]}')

print(f'\nTotal occurrences found: {total_flags}')

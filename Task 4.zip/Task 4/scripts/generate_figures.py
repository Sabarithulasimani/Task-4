import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches

# Create target directory
os.makedirs('presentation/figures', exist_ok=True)

# Okabe-Ito Palette
# Black: #000000, Orange: #E69F00, Sky Blue: #56B4E9, Bluish Green: #009E73,
# Yellow: #F0E442, Blue: #0072B2, Vermilion: #D55E00, Reddish Purple: #CC79A7
OI_BLUE = '#0072B2'
OI_VERMILION = '#D55E00'
OI_GREEN = '#009E73'
OI_ORANGE = '#E69F00'
OI_SKY_BLUE = '#56B4E9'
OI_DARK = '#2B2B2B'
OI_GRAY = '#7F7F7F'
OI_LIGHT_BG = '#F8F9FA'

plt.rcParams['font.sans-serif'] = 'Arial'
plt.rcParams['font.size'] = 12
plt.rcParams['axes.edgecolor'] = '#CCCCCC'
plt.rcParams['axes.linewidth'] = 0.8

df = pd.read_csv('data/clean/customer_churn_clean.csv')

# --- FIGURE 1: Churn by Contract Type ---
fig, ax = plt.subplots(figsize=(6.5, 4.2), dpi=300)
contracts = ['Month-to-Month', 'One Year', 'Two Year']
churn_rates = [100.0, 0.0, 0.0]
counts = ['7 / 7 churned', '0 / 4 churned', '0 / 4 churned']
colors = [OI_VERMILION, OI_BLUE, OI_BLUE]

bars = ax.bar(contracts, churn_rates, color=colors, width=0.55, edgecolor='none')
ax.set_ylim(0, 118)
ax.set_ylabel('Churn Rate (%)', fontsize=12, fontweight='bold', color=OI_DARK)
ax.set_title('Churn Rate by Contract Type', fontsize=14, fontweight='bold', pad=15, color=OI_DARK)

for bar, rate, count in zip(bars, churn_rates, counts):
    height = bar.get_height()
    label_y = height + 3 if height > 0 else 3
    ax.text(bar.get_x() + bar.get_width() / 2, label_y,
            f'{rate:.1f}%\n({count})',
            ha='center', va='bottom', fontsize=11, fontweight='bold', color=OI_DARK)

ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.grid(axis='y', linestyle='--', alpha=0.5)
ax.text(0.99, -0.15, 'Source: customer_churn_sample.csv, n = 15',
        ha='right', va='top', transform=ax.transAxes, fontsize=9, color=OI_GRAY, fontstyle='italic')

plt.tight_layout()
fig.savefig('presentation/figures/fig1_contract_churn.png', bbox_inches='tight')
plt.close()
print('Generated fig1_contract_churn.png')


# --- FIGURE 2: Churn by Tenure Band ---
def get_tenure_band(t):
    if t <= 6:
        return '0-6 mo'
    elif t <= 12:
        return '7-12 mo'
    elif t <= 24:
        return '13-24 mo'
    else:
        return '25+ mo'

df['TenureBand'] = df['TenureMonths'].apply(get_tenure_band)
band_order = ['0-6 mo', '7-12 mo', '13-24 mo', '25+ mo']

band_stats = []
for b in band_order:
    sub = df[df['TenureBand'] == b]
    rate = sub['Churn_Flag'].mean() * 100
    c_churn = sub['Churn_Flag'].sum()
    c_total = len(sub)
    band_stats.append((rate, c_churn, c_total))

fig, ax = plt.subplots(figsize=(6.5, 4.2), dpi=300)
rates = [s[0] for s in band_stats]
labels = [f'{s[1]} / {s[2]} churned' for s in band_stats]
colors = [OI_VERMILION, OI_VERMILION, OI_ORANGE, OI_BLUE]

bars = ax.bar(band_order, rates, color=colors, width=0.55, edgecolor='none')
ax.set_ylim(0, 118)
ax.set_ylabel('Churn Rate (%)', fontsize=12, fontweight='bold', color=OI_DARK)
ax.set_title('Churn Rate by Customer Tenure Band', fontsize=14, fontweight='bold', pad=15, color=OI_DARK)

for bar, rate, count_lbl in zip(bars, rates, labels):
    height = bar.get_height()
    label_y = height + 3 if height > 0 else 3
    ax.text(bar.get_x() + bar.get_width() / 2, label_y,
            f'{rate:.1f}%\n({count_lbl})',
            ha='center', va='bottom', fontsize=10, fontweight='bold', color=OI_DARK)

ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.grid(axis='y', linestyle='--', alpha=0.5)
ax.text(0.99, -0.15, 'Source: customer_churn_sample.csv, n = 15',
        ha='right', va='top', transform=ax.transAxes, fontsize=9, color=OI_GRAY, fontstyle='italic')

plt.tight_layout()
fig.savefig('presentation/figures/fig2_tenure_churn.png', bbox_inches='tight')
plt.close()
print('Generated fig2_tenure_churn.png')


# --- FIGURE 3: Support Tickets by Churn Status ---
fig, ax = plt.subplots(figsize=(6.5, 4.2), dpi=300)

churn_tickets = df[df['Churn'] == 'Yes']['SupportTickets']
retained_tickets = df[df['Churn'] == 'No']['SupportTickets']

means = [churn_tickets.mean(), retained_tickets.mean()]
medians = [churn_tickets.median(), retained_tickets.median()]
categories = ['Churned\n(n = 7)', 'Retained\n(n = 8)']
bar_colors = [OI_VERMILION, OI_BLUE]

bars = ax.bar(categories, means, color=bar_colors, width=0.5, edgecolor='none', alpha=0.9)
ax.set_ylim(0, 6.2)
ax.set_ylabel('Average Support Tickets', fontsize=12, fontweight='bold', color=OI_DARK)
ax.set_title('Support Ticket Volume by Churn Status', fontsize=14, fontweight='bold', pad=15, color=OI_DARK)

# Threshold line at 3 tickets
ax.axhline(3.0, color=OI_ORANGE, linestyle='--', linewidth=2, label='Friction Threshold (≥3 tickets)')
ax.legend(loc='upper right', frameon=True, fontsize=10)

for bar, mean_val, med_val in zip(bars, means, medians):
    ax.text(bar.get_x() + bar.get_width() / 2, mean_val + 0.18,
            f'Mean: {mean_val:.2f}\nMedian: {med_val:.1f}',
            ha='center', va='bottom', fontsize=11, fontweight='bold', color=OI_DARK)

ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.grid(axis='y', linestyle='--', alpha=0.5)
ax.text(0.99, -0.15, 'Source: customer_churn_sample.csv, n = 15',
        ha='right', va='top', transform=ax.transAxes, fontsize=9, color=OI_GRAY, fontstyle='italic')

plt.tight_layout()
fig.savefig('presentation/figures/fig3_tickets_churn.png', bbox_inches='tight')
plt.close()
print('Generated fig3_tickets_churn.png')


# --- FIGURE 4: KPI Summary Cards ---
fig, ax = plt.subplots(figsize=(10, 3.8), dpi=300)
ax.axis('off')

kpi_data = [
    {'title': 'Churn Rate', 'value': '46.7%', 'sub': '7 of 15 customers', 'color': OI_VERMILION},
    {'title': 'Retention Rate', 'value': '53.3%', 'sub': '8 of 15 active', 'color': OI_BLUE},
    {'title': 'Revenue Lost', 'value': '$409.93', 'sub': '/ mo (32.3% of MRR)', 'color': OI_VERMILION},
    {'title': 'Revenue at Risk', 'value': '$129.98', 'sub': '/ mo (Medium tier: 2 accts)', 'color': OI_ORANGE},
    {'title': 'Average Tenure', 'value': '18.8 mo', 'sub': '7.0 mo churn vs 29.1 active', 'color': OI_GREEN}
]

for i, kpi in enumerate(kpi_data):
    x = 0.02 + i * 0.196
    y = 0.1
    w = 0.18
    h = 0.8
    # Background card
    rect = patches.FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.03,rounding_size=0.04",
                                  facecolor=OI_LIGHT_BG, edgecolor=kpi['color'], linewidth=2.5)
    ax.add_patch(rect)
    
    # Title
    ax.text(x + w/2, y + 0.65, kpi['title'], ha='center', va='center',
            fontsize=12, fontweight='bold', color=OI_DARK)
    # Value
    ax.text(x + w/2, y + 0.40, kpi['value'], ha='center', va='center',
            fontsize=20, fontweight='bold', color=kpi['color'])
    # Subtext
    ax.text(x + w/2, y + 0.18, kpi['sub'], ha='center', va='center',
            fontsize=9.5, color=OI_DARK, wrap=True)

ax.text(0.99, -0.05, 'Source: customer_churn_sample.csv, n = 15',
        ha='right', va='top', transform=ax.transAxes, fontsize=9, color=OI_GRAY, fontstyle='italic')

plt.tight_layout()
fig.savefig('presentation/figures/fig4_kpi_cards.png', bbox_inches='tight')
plt.close()
print('Generated fig4_kpi_cards.png')


# --- FIGURE 5: Risk Tier Score Distribution ---
fig, ax = plt.subplots(figsize=(7.5, 4.2), dpi=300)
tiers = ['High Risk (≥4.0)', 'Medium Risk (2.0–3.5)', 'Low Risk (<2.0)']
active_counts = [0, 2, 6]
churned_counts = [5, 2, 0]

x = np.arange(len(tiers))
width = 0.38

bars1 = ax.bar(x - width/2, churned_counts, width, label='Churned Accounts', color=OI_VERMILION)
bars2 = ax.bar(x + width/2, active_counts, width, label='Active Accounts', color=OI_BLUE)

ax.set_ylabel('Number of Customers', fontsize=12, fontweight='bold', color=OI_DARK)
ax.set_title('Customer Distribution by Churn-Risk Tier', fontsize=14, fontweight='bold', pad=15, color=OI_DARK)
ax.set_xticks(x)
ax.set_xticklabels(tiers, fontsize=11, fontweight='bold', color=OI_DARK)
ax.set_ylim(0, 7.2)
ax.legend(frameon=True, fontsize=11)

for bar in bars1:
    h = bar.get_height()
    if h > 0:
        ax.text(bar.get_x() + bar.get_width()/2, h + 0.15, str(int(h)),
                ha='center', va='bottom', fontsize=11, fontweight='bold', color=OI_DARK)

for bar in bars2:
    h = bar.get_height()
    if h > 0:
        ax.text(bar.get_x() + bar.get_width()/2, h + 0.15, str(int(h)),
                ha='center', va='bottom', fontsize=11, fontweight='bold', color=OI_DARK)

ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.grid(axis='y', linestyle='--', alpha=0.5)
ax.text(0.99, -0.15, 'Source: customer_churn_sample.csv, n = 15',
        ha='right', va='top', transform=ax.transAxes, fontsize=9, color=OI_GRAY, fontstyle='italic')

plt.tight_layout()
fig.savefig('presentation/figures/fig5_risk_score_distribution.png', bbox_inches='tight')
plt.close()
print('Generated fig5_risk_score_distribution.png')


# --- FIGURE 6: Impact Scenarios Chart ---
fig, ax = plt.subplots(figsize=(7.5, 4.2), dpi=300)
scenarios = ['Conservative\n(15% lift)', 'Base Case\n(30% lift)', 'Optimistic\n(50% lift)']
retained_active_mrr = [19.50, 38.99, 64.99]
prevented_inflow_mrr = [40.99, 102.48, 163.97]

x = np.arange(len(scenarios))
width = 0.45

p1 = ax.bar(x, retained_active_mrr, width, label='Retained Active MRR (Base: $129.98)', color=OI_BLUE)
p2 = ax.bar(x, prevented_inflow_mrr, width, bottom=retained_active_mrr, label='Prevented Inflow Churn (Base: $409.93)', color=OI_GREEN)

ax.set_ylabel('Monthly Revenue Retained ($ / mo)', fontsize=12, fontweight='bold', color=OI_DARK)
ax.set_title('Modeled Monthly Revenue Retained by Scenario', fontsize=14, fontweight='bold', pad=15, color=OI_DARK)
ax.set_xticks(x)
ax.set_xticklabels(scenarios, fontsize=11, fontweight='bold', color=OI_DARK)
ax.set_ylim(0, 260)
ax.legend(frameon=True, fontsize=10, loc='upper left')

# Total labels on top of stacked bars
for i, (a, b) in enumerate(zip(retained_active_mrr, prevented_inflow_mrr)):
    tot = a + b
    ann = tot * 12
    ax.text(i, tot + 5, f'${tot:.2f} / mo\n(${ann:,.0f} / yr)', ha='center', va='bottom', fontsize=11, fontweight='bold', color=OI_DARK)

ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.grid(axis='y', linestyle='--', alpha=0.5)

# Watermark / Notice
ax.text(0.5, 0.65, 'ASSUMPTIONS ONLY — NOT A GUARANTEE', transform=ax.transAxes,
        fontsize=11, color='red', alpha=0.3, fontweight='bold', ha='center', rotation=10)

ax.text(0.99, -0.18, 'Source: Modeled from customer_churn_clean.csv (n = 15)',
        ha='right', va='top', transform=ax.transAxes, fontsize=9, color=OI_GRAY, fontstyle='italic')

plt.tight_layout()
fig.savefig('presentation/figures/fig6_impact_scenarios.png', bbox_inches='tight')
plt.close()
print('Generated fig6_impact_scenarios.png')

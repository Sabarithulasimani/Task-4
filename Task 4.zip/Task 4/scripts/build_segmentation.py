import pandas as pd
import numpy as np
import os

# Ensure directories exist
os.makedirs('outputs', exist_ok=True)
os.makedirs('reports', exist_ok=True)

df = pd.read_csv('data/clean/customer_churn_clean.csv')

# 1. Assign Segment
def get_segment(row):
    if row['ContractType'] == 'Month-to-Month':
        return 'High-Friction Starters'
    elif row['ContractType'] == 'One Year':
        return 'Mid-Tenure Stabilizers'
    else:
        return 'Enterprise Anchors'

df['Segment'] = df.apply(get_segment, axis=1)

# 2. Risk Score calculation
def score_row(row):
    # Contract
    c_pts = 2.0 if row['ContractType'] == 'Month-to-Month' else (1.0 if row['ContractType'] == 'One Year' else 0.0)
    # Tickets
    t_pts = 2.0 if row['SupportTickets'] >= 4 else (1.0 if row['SupportTickets'] >= 2 else 0.0)
    # Tenure
    ten_pts = 1.0 if row['TenureMonths'] <= 6 else (0.5 if row['TenureMonths'] <= 12 else 0.0)
    
    score = c_pts + t_pts + ten_pts
    return pd.Series([c_pts, t_pts, ten_pts, score], index=['ContractRiskPoints', 'TicketRiskPoints', 'TenureRiskPoints', 'ChurnRiskScore'])

scores = df.apply(score_row, axis=1)
df = pd.concat([df, scores], axis=1)

def get_tier(score):
    if score >= 4.0:
        return 'High'
    elif score >= 2.0:
        return 'Medium'
    else:
        return 'Low'

df['RiskTier'] = df['ChurnRiskScore'].apply(get_tier)

# Active customer priority ranking
df['RetentionPriority'] = 'N/A (Churned)'
active_mask = df['Churn'] == 'No'
active_sorted = df[active_mask].sort_values(by=['ChurnRiskScore', 'MonthlyCharges', 'SupportTickets'], ascending=[False, False, False])
for rank, idx in enumerate(active_sorted.index, 1):
    df.loc[idx, 'RetentionPriority'] = f'Priority {rank}'

df.to_csv('outputs/customer_risk_scores.csv', index=False)
print('Saved outputs/customer_risk_scores.csv')

# Segment table
seg_summary = []
# Predefined order
order = ['High-Friction Starters', 'Mid-Tenure Stabilizers', 'Enterprise Anchors']
for name in order:
    group = df[df['Segment'] == name]
    churn_rate = f"{round(group['Churn_Flag'].mean() * 100, 1)}%"
    story = {
        'High-Friction Starters': 'Early-stage monthly customers facing high ticket friction who churned before month 15.',
        'Mid-Tenure Stabilizers': 'Established annual subscribers with moderate support needs nearing contract renewal.',
        'Enterprise Anchors': 'High-value enterprise accounts on two-year commitments with zero churn and high stability.'
    }[name]
    
    seg_summary.append({
        'SegmentName': name,
        'CustomerCount': len(group),
        'PctOfCustomers': round(len(group) / len(df) * 100, 1),
        'ContractTypes': ', '.join(group['ContractType'].unique()),
        'SubscriptionTypes': ', '.join(group['SubscriptionType'].unique()),
        'AvgTenureMonths': round(group['TenureMonths'].mean(), 1),
        'AvgSupportTickets': round(group['SupportTickets'].mean(), 2),
        'HistoricalChurnRate': churn_rate,
        'MonthlyRevenue': round(group['MonthlyCharges'].sum(), 2),
        'PctTotalRevenue': round(group['MonthlyCharges'].sum() / df['MonthlyCharges'].sum() * 100, 1),
        'CurrentStatus': 'All Churned' if group['Churn_Flag'].mean() == 1.0 else 'All Active',
        'OneLineStory': story
    })

seg_df = pd.DataFrame(seg_summary)
seg_df.to_csv('outputs/segment_table.csv', index=False)
print('Saved outputs/segment_table.csv')
print(seg_df[['SegmentName', 'CustomerCount', 'HistoricalChurnRate', 'MonthlyRevenue', 'OneLineStory']])

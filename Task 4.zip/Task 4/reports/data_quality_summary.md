# Data Quality Summary Report
## Customer Churn Dataset — EDVYRO Internship Task 02

---

## 1. Dataset Overview

| Attribute | Value |
|---|---|
| **Source** | Synthetic dataset — `customer_churn_sample.csv` |
| **URL** | https://edvyro.in/datasets/customer_churn_sample.csv |
| **Shape** | 15 rows × 11 columns |
| **Memory** | ~6.3 KB |
| **Date profiled** | November 2026 |
| **Purpose** | Demonstrate a reproducible data-quality and EDA workflow |

**Columns:** `CustomerID`, `Gender`, `Age`, `TenureMonths`, `SubscriptionType`, `MonthlyCharges`, `TotalCharges`, `ContractType`, `SupportTickets`, `PaymentMethod`, `Churn`

> ⚠️ **Small-sample caveat:** This is a synthetic sample of only **15 records**. All patterns and statistics are illustrative only. No statistically significant conclusions can be drawn.

---

## 2. Quality-Check Results Table

| Check | Result | Action |
|---|---|---|
| Shape and column names | 15 rows × 11 columns; all expected columns present | No action needed |
| Data types | Numeric columns correctly loaded as int64/float64; string columns as object | No action needed |
| Standard missing values (NaN) | **0 missing values** across all columns | No action needed |
| Hidden missing (empty string, "NA", "null", "?") | **0 hidden missing** in any string column | No action needed |
| Full-row duplicates | **0 duplicates** | No action needed |
| Duplicate CustomerIDs | **0 duplicate IDs** (all 15 are unique) | No action needed |
| Categorical casing/whitespace | All categories consistently cased; no whitespace issues | str.strip() applied as defensive measure |
| Numeric outliers (IQR) | **0 IQR outliers** in any numeric column | No action needed |
| Numeric outliers (z-score \|z\| > 3) | **0 z-score outliers** in any numeric column | No action needed |
| Impossible values (Age < 18 or > 100) | **0 impossible age values** (range: 23–60) | No action needed |
| Impossible values (Tenure < 0) | **0 negative tenure values** | No action needed |
| Impossible values (Charges ≤ 0) | **0 non-positive charge values** | No action needed |
| Impossible values (SupportTickets < 0) | **0 negative ticket values** | No action needed |
| TotalCharges ≈ TenureMonths × MonthlyCharges | **All 15 rows pass** within ±$0.05 tolerance | No correction needed |

**Overall raw data quality: Excellent.** The synthetic dataset was designed to be clean.

---

## 3. Cleaning Decisions and Assumptions

The table below documents every decision made during cleaning. If a check found no issue, that outcome is recorded explicitly rather than omitted.

| # | Issue | Evidence | Action Taken | Rationale | Rows Affected |
|---|---|---|---|---|---|
| 1 | Whitespace in string columns | Preventive check — 0 cells with whitespace | Checked, no issue found | Whitespace causes silent mismatches in groupby / merge operations | 0 |
| 2 | Gender casing consistency | All values already in Title Case (Female / Male) | Checked, no issue found | Defensive standardisation via str.title() | 0 |
| 3 | Integer dtype assertion | Age, TenureMonths, SupportTickets correctly loaded as int64 | Checked, no issue found | Defensive type assertion for downstream safety | 0 |
| 4 | Full-row duplicates | 0 duplicate rows found | Checked, no issue found | Duplicates would inflate counts and bias statistics | 0 |
| 5 | TotalCharges vs TenureMonths × MonthlyCharges | 0 mismatches beyond ±$0.05 tolerance | Checked, no issue found | Small floating-point rounding is expected; large gaps require investigation | 0 |
| 6 | Churn numeric flag (new column) | Churn is text (Yes/No); numeric encoding needed for modelling | Created `Churn_Flag` (Yes=1, No=0) | Required by downstream dashboard and segmentation tasks | All 15 |

**Assumption:** The ±$0.05 tolerance for the TotalCharges consistency check is chosen to accommodate standard floating-point arithmetic rounding (two decimal places × up to 48 months). Any discrepancy larger than this would indicate a data entry error.

---

## 4. Validation Results

All 12 assertion-based checks were run on the cleaned dataset. **All 12 passed.**

| Check | Result |
|---|---|
| CustomerID is unique | ✅ PASS |
| CustomerID has no nulls | ✅ PASS |
| Churn contains only 'Yes' / 'No' | ✅ PASS |
| Churn_Flag contains only 0 / 1 | ✅ PASS |
| MonthlyCharges > 0 for all rows | ✅ PASS |
| TotalCharges ≈ TenureMonths × MonthlyCharges (±$0.05) | ✅ PASS |
| SubscriptionType in {Basic, Pro, Enterprise} | ✅ PASS |
| ContractType in {Month-to-Month, One Year, Two Year} | ✅ PASS |
| PaymentMethod in {Credit Card, Bank Transfer, UPI, Debit Card} | ✅ PASS |
| Age between 18 and 100 (inclusive) | ✅ PASS |
| SupportTickets ≥ 0 | ✅ PASS |
| TenureMonths ≥ 0 | ✅ PASS |

**Before/After Reconciliation:**
- Raw: 15 rows × 11 columns
- Clean: 15 rows × 12 columns (+1 `Churn_Flag` column; 0 rows removed)

---

## 5. Key Initial Patterns

> All statistics are from n=15 records and are **directional only**.

| Pattern | Key Number | Caveat |
|---|---|---|
| Overall churn rate | **46.7%** (7 of 15 customers churned) | Small sample; not generalisable |
| Strongest categorical predictor | Month-to-month: **100% churn**; Two-year: **0% churn** | n=7 and n=4 respectively |
| Subscription tier | Basic: **71.4%** churn; Enterprise: **0%** churn | Correlated with contract type |
| Tenure difference | Churned avg: **7.0 months**; Retained avg: **29.1 months** | 22-month gap |
| Support tickets | Churned avg: **4.3 tickets**; Retained avg: **1.0 tickets** | Potential early-warning signal |
| Strongest correlations with Churn_Flag | SupportTickets: **r = 0.88**; TenureMonths: **r = -0.80** | n=15; treat as directional |

---

## 6. Limitations

1. **Tiny sample size (n=15):** No statistical inference is valid. Patterns with 100% or 0% rates are artefacts of small groups, not reliable signals.
2. **Synthetic data:** The dataset was artificially generated. Real-world noise, entry errors, and edge cases are absent, making the data unusually clean.
3. **No time dimension:** There is no timestamp or cohort date. It is impossible to analyse churn over time, seasonal effects, or customer lifecycle stages.
4. **No feature engineering:** Derived features (e.g., revenue per month, support ticket rate per tenure month) have not been computed.
5. **No external validation:** The dataset cannot be cross-referenced with external sources to verify accuracy.
6. **Confounded variables:** Contract type and subscription type are closely correlated — it is not possible to separate their effects in this sample.

---

## 7. Suggested Next Steps

These feed directly into the later EDVYRO internship tasks:

1. **Task 03 — Business KPI Dashboard:**
   - Track churn rate, revenue at risk (churned customers × MonthlyCharges), and retention rate.
   - Build interactive filters by ContractType and SubscriptionType.

2. **Task 04 — Segmentation and Recommendation Model:**
   - Segment customers by contract type × subscription type × support ticket volume.
   - Build a rule-based churn-risk score using: ContractType = Month-to-Month (+2), SupportTickets ≥ 4 (+2), TenureMonths ≤ 6 (+1).

3. **Data collection improvements:**
   - Collect at least 200–500 real customer records with timestamps before modelling.
   - Add features: last login date, number of plan changes, payment failure history.
   - Track churn date to enable survival analysis.

4. **Statistical validation (once data grows):**
   - Chi-square tests for categorical associations.
   - T-tests or Mann-Whitney U for numeric feature differences by churn status.
   - Logistic regression with cross-validation.

---

*Report generated as part of EDVYRO Internship Task 02 — Data Quality and Exploratory Analysis.*

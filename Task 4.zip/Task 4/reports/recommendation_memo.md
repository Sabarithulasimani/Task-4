# Executive Recommendation Memo: Customer Segmentation & Churn Risk Mitigation

**TO:** Executive Leadership Team (VP Customer Success, VP Product, Head of Revenue)  
**FROM:** Senior Data Analyst  
**DATE:** November 2026  
**SUBJECT:** Data-Driven Customer Segmentation, Explainable Churn-Risk Scoring, and Strategic Action Plan  
**STATUS:** Recommendation & Decision Brief  

---

## 1. Executive Summary

This memorandum translates our descriptive exploratory analysis into an **explainable, rule-based prioritization model** and an actionable retention strategy. 

In our analyzed customer cohort ($n = 15$), the overall churn rate is **46.7%** (7 of 15 customers), representing **$409.93 / month** ($4,919.16 annualized) in lost recurring revenue. All churn occurred exclusively among early-tenure, Month-to-Month subscribers experiencing elevated technical support friction (average 4.3 tickets). 

To prevent future revenue erosion and protect our active subscriber base ($859.92 / month across 8 accounts), we developed a transparent, rule-based **Churn-Risk Scoring Model (0–5 points)** that segments customers into High, Medium, and Low risk tiers. Among active customers, **2 accounts (CUST-1009 and CUST-1006)** representing **$129.98 / month** in recurring revenue fall into the **Medium-Risk tier** due to upcoming annual renewals and unresolved support interactions. 

We recommend three targeted interventions across a 90-day phased rollout:
1. **Targeted Onboarding & Ticket Deflection** for new and monthly subscribers (Owner: Customer Success Lead; Days 1–30).
2. **Contract Migration & Annual Incentive Campaign** for mid-tier accounts (Owner: Growth / Sales Lead; Days 30–60).
3. **Dedicated Enterprise Stewardship & Proactive QBRs** for multi-year accounts (Owner: Head of Account Management; Days 60–90).

Depending on intervention efficacy, successfully retaining 15% to 50% of at-risk active revenue protects **$19.50 to $64.99 / month** ($234 to $780 / year), while preventing 25% of prospective early-stage churn recovers **$102.48 / month** ($1,230 / year).

> ⚠️ **Dataset Notice:** All calculations are derived from `customer_churn_clean.csv` ($n = 15$ synthetic sample). Patterns are illustrative benchmarks to establish decision frameworks, not statistically proven population truths.

---

## 2. Feature Selection & Rationale

To build a transparent and actionable model, we evaluated behavioral and account characteristics against churn outcomes:

| Feature | Feature Type | Correlation with Churn | Strategic Rationale |
|---|---|---|---|
| **ContractType** | Account Structure | Strong Negative ($r = -0.85$ rank) | Strongest categorical discriminator. Month-to-Month accounts lack switching barriers (100% churn in sample), whereas 1-Year and 2-Year commitments provide stability (0% churn). |
| **SupportTickets** | Behavioral / Experience | Strong Positive ($r = +0.88$) | High ticket volumes (3–6 tickets) signal severe customer friction, unmet product expectations, or unresolved bugs prior to cancellation. |
| **TenureMonths** | Lifecycle Timing | Strong Negative ($r = -0.80$) | Churn is heavily concentrated in the early customer lifecycle (mean churned tenure: 7.0 months vs. 29.1 months for retained). |
| **SubscriptionType** | Account Value | Moderate ($r = -0.58$) | Basic ($49.99) and Pro ($79.99) tiers show higher vulnerability than Enterprise ($149.99), though strongly confounded with ContractType. |
| **MonthlyCharges** | Financial / Value | Moderate Negative ($r = -0.63$) | Higher-paying accounts are on long-term enterprise contracts; lower-spend accounts exhibit higher churn velocity. |

Demographic features (`Age`, `Gender`) and payment methods (`Credit Card`, `UPI`, `Bank Transfer`) showed secondary or collinear relationships and were excluded from scoring to maintain an explainable, auditable rule structure.

---

## 3. Customer Segments & Behavioral Cohorts

We partitioned the customer base into three distinct operational segments:

```
+---------------------------------------------------------------------------------------------------+
| Total Customer Base (n = 15 | $1,269.85/mo MRR)                                                   |
+------------------------------------+----------------------------------+---------------------------+
| Segment 1: High-Friction Starters  | Segment 2: Mid-Tenure Stabilizers| Segment 3: Enterprise     |
| • 7 accounts (46.7%)               | • 4 accounts (26.7%)             | • 4 accounts (26.7%)      |
| • Month-to-Month Contracts         | • One-Year Contracts             | • Two-Year Contracts      |
| • 100% Historical Churn           | • 0% Historical Churn            | • 0% Historical Churn     |
| • $409.93/mo Lost Revenue          | • $259.96/mo Active Revenue      | • $599.96/mo Active Rev   |
+------------------------------------+----------------------------------+---------------------------+
```

### Segment Table Summary (`outputs/segment_table.csv`)

| Segment Name | Count | % Cust | Contracts | Subscriptions | Avg Tenure | Avg Tickets | Churn Rate | Monthly Revenue | Status | Strategic Summary |
|---|---|---|---|---|---|---|---|---|---|---|
| **High-Friction Starters** | 7 | 46.7% | Month-to-Month | Basic, Pro | 7.0 mo | 4.29 | 100.0% | $409.93 | Churned | Early-stage monthly subscribers who faced severe friction and left before month 15. |
| **Mid-Tenure Stabilizers** | 4 | 26.7% | One Year | Pro, Basic | 19.8 mo | 1.50 | 0.0% | $259.96 | Active | Annual subscribers with moderate support interactions approaching annual renewal. |
| **Enterprise Anchors** | 4 | 26.7% | Two Year | Enterprise | 38.5 mo | 0.50 | 0.0% | $599.96 | Active | High-value, multi-year accounts with minimal friction, delivering stable recurring cash flow. |

---

## 4. Transparent Rule-Based Churn-Risk Scoring Model

### 4.1 Scoring Formula & Weights

To ensure complete audibility across non-technical stakeholders, the **Churn-Risk Score** ($S$) computes additive penalty points based on observable risk drivers:

$$S = \text{ContractPoints} + \text{TicketPoints} + \text{TenurePoints}$$

Where:
1. **Contract Risk Points:**
   - `Month-to-Month`: **+2.0 pts** (no contractual barrier; instant cancellation ability)
   - `One Year`: **+1.0 pt** (renewal decision point occurs every 12 months)
   - `Two Year`: **0.0 pts** (extended multi-year stability)
2. **Support Ticket Friction Points:**
   - `SupportTickets >= 4`: **+2.0 pts** (critical distress / acute dissatisfaction)
   - `SupportTickets in [2, 3]`: **+1.0 pt** (moderate friction / repeat contact)
   - `SupportTickets <= 1`: **0.0 pts** (low friction / stable experience)
3. **Tenure / Lifecycle Vulnerability Points:**
   - `TenureMonths <= 6`: **+1.0 pt** (early trial / high vulnerability window)
   - `TenureMonths in [7, 12]`: **+0.5 pts** (first-year evaluation phase)
   - `TenureMonths > 12`: **0.0 pts** (established habitual usage)

### 4.2 Risk Tiers & In-Sample Separation

The composite score ranges from **0.0 to 5.0**:
- **High Risk ($S \ge 4.0$):** 5 customers. 100% churned ($5/5$).
- **Medium Risk ($2.0 \le S < 4.0$):** 4 customers. 50% churned ($2/4$), 50% active ($2/4$).
- **Low Risk ($S < 2.0$):** 6 customers. 0% churned ($0/6$), 100% active ($6/6$).

### 4.3 Edge Case & Boundary Validation

We validated boundary conditions against prospective and historical extremes:
- **Minimum Score Boundary ($S = 0.0$):** Two-Year contract, $\le 1$ ticket, tenure $>12$ mo. Validated on CUST-1004 & CUST-1011 (actual active enterprise accounts).
- **Maximum Score Boundary ($S = 5.0$):** Month-to-Month, $\ge 4$ tickets, tenure $\le 6$ mo. Validated on CUST-1003, CUST-1007, CUST-1010, CUST-1014 (all churned within 2–6 months).
- **Threshold Discontinuities:** 
  - A customer at tenure month 12 receives 0.5 pts, stepping down to 0.0 pts at month 13, reflecting survival past the critical first-year hazard peak.
  - A customer logging a 2nd ticket transitions from 0 to 1 point; reaching 4 tickets adds another point, capturing escalating dissatisfaction without artificial exponential scaling.

---

## 5. Active Customer Prioritization & Account Risk Profile

Applying the model to all currently active accounts ($n = 8$) yields an explicit triage ranking:

| Priority Rank | CustomerID | Segment | Contract | Tenure | Tickets | Monthly Charges | Risk Score | Risk Tier | Primary Vulnerability |
|---|---|---|---|---|---|---|---|---|---|
| **Priority 1** | **CUST-1009** | Mid-Tenure Stabilizers | One Year | 15 mo | 2 | **$79.99** | **2.0** | **Medium** | Pro tier spend; 2 support tickets; 1st annual renewal window |
| **Priority 2** | **CUST-1006** | Mid-Tenure Stabilizers | One Year | 18 mo | 2 | **$49.99** | **2.0** | **Medium** | Basic tier; 2 support tickets; potential renewal fatigue |
| **Priority 3** | **CUST-1002** | Mid-Tenure Stabilizers | One Year | 24 mo | 1 | **$79.99** | **1.0** | **Low** | 2-year anniversary renewal; low ticket friction |
| **Priority 4** | **CUST-1013** | Mid-Tenure Stabilizers | One Year | 22 mo | 1 | **$49.99** | **1.0** | **Low** | Basic tier; single ticket; approaching year-2 renewal |
| **Priority 5** | **CUST-1008** | Enterprise Anchors | Two Year | 48 mo | 1 | **$149.99** | **0.0** | **Low** | Longest tenure (4 years); highly stable; standard review |
| **Priority 6** | **CUST-1015** | Enterprise Anchors | Two Year | 40 mo | 1 | **$149.99** | **0.0** | **Low** | Highly stable enterprise account; standard review |
| **Priority 7** | **CUST-1004** | Enterprise Anchors | Two Year | 36 mo | 0 | **$149.99** | **0.0** | **Low** | Zero support tickets; premium enterprise benchmark |
| **Priority 8** | **CUST-1011** | Enterprise Anchors | Two Year | 30 mo | 0 | **$149.99** | **0.0** | **Low** | Zero support tickets; premium enterprise benchmark |

### Reconciling Active Risk vs. Earlier KPI Dashboard
In Task 03 (`dashboard/index.html` & `docs/kpi_definitions.md`), the strict historical rule `ContractType = "Month-to-Month" AND SupportTickets >= 3` evaluated to **$0.00 Revenue at Risk** because 100% of Month-to-Month accounts had already churned. 
Our prospective Churn-Risk scoring model expands this lens to active accounts: **$129.98 / month** across **CUST-1009** ($79.99) and **CUST-1006** ($49.99) is currently exposed to elevated risk due to support friction and upcoming annual expirations.

---

## 6. Strategic Recommendations & Operational Plan

We recommend three concrete interventions directly mapped to segments, with assigned owners and measurable milestones:

```
Timeline: 90-Day Implementation Horizon
Month 1 (Days 1-30)   ===> Action 1: Rapid Support Triage & High-Touch Onboarding
Month 2 (Days 30-60)  ===> Action 2: Annual Contract Migration & Discount Incentives
Month 3 (Days 60-90)  ===> Action 3: Enterprise Executive Reviews & Multi-Year Anchoring
```

### Action 1: Onboarding Check-in & Rapid Support Escalation (Days 1–30)
- **Target Segment:** High-Friction Starters (new and early-tenure month-to-month accounts)
- **Operational Owner:** Customer Success Lead
- **Mechanism:** Implement an automated alert triggering when any customer submits $\ge 2$ tickets within their first 90 days. A Senior Support Specialist must conduct a direct outreach call within 24 hours to resolve underlying technical blockers.
- **Success Metric:** Reduce early-life support escalations by 50%; improve first-contact resolution to $>85\%$.

### Action 2: Proactive Annual Contract Migration Incentives (Days 30–60)
- **Target Segment:** Mid-Tenure Stabilizers & Month-to-Month Pro users (specifically targeting CUST-1009 and CUST-1006)
- **Operational Owner:** Sales / Growth Marketing Lead
- **Mechanism:** Offer a 15% discount or 2 free months on an annual agreement for accounts nearing their 12-month or 24-month mark, coupled with dedicated onboarding reviews to eliminate remaining ticket friction.
- **Success Metric:** Convert at least 50% of eligible at-risk accounts (CUST-1009 / CUST-1006) to multi-year or renewed annual commitments.

### Action 3: Dedicated Account Management & Quarterly Value Reviews (Days 60–90)
- **Target Segment:** Enterprise Anchors (CUST-1004, 1008, 1011, 1015)
- **Operational Owner:** Head of Strategic Account Management
- **Mechanism:** Formalize semi-annual Executive Business Reviews (EBRs) with designated Technical Account Managers (TAMs) to ensure roadmap alignment and secure early renewals 6 months prior to contract expiry.
- **Success Metric:** Maintain 100% net revenue retention across the Enterprise tier ($599.96 / month baseline).

---

## 7. Expected Impact & Scenario Modeling

All financial impacts are calculated transparently from our clean dataset. To maintain executive credibility, **these figures represent illustrative scenario models based on explicit assumptions, not predictive guarantees or financial forecasts.**

### Scenario Assumptions
1. **Target Population 1 (Active Medium-Risk Cohort):** CUST-1009 ($79.99) and CUST-1006 ($49.99) = **$129.98 / month**.
2. **Target Population 2 (Prospective Early Inflow / Month-to-Month Baseline):** Historical monthly churn = **$409.93 / month**.
3. **Intervention Cost Assumption:** Average discount or retention concession of ~15% of plan value during renewal promotion.

### Scenario Impact Table

| Scenario | Modeled Retention Lift | Retained Active MRR (Base: $129.98) | Retained Active Annual Revenue | Prevented Inflow Churn (Base: $409.93) | Prevented Inflow Annual Value | Net Value Retained (Monthly) |
|---|---|---|---|---|---|---|
| **Conservative** | 15% of at-risk revenue | **$19.50 / mo** | $233.96 / yr | **$40.99 / mo** | $491.92 / yr | **$60.49 / mo** |
| **Base Case** | 30% of at-risk revenue | **$38.99 / mo** | $467.93 / yr | **$102.48 / mo** | $1,229.79 / yr | **$141.48 / mo** |
| **Optimistic** | 50% of at-risk revenue | **$64.99 / mo** | $779.88 / yr | **$163.97 / mo** | $1,967.66 / yr | **$228.96 / mo** |

*Note: Calculations follow $\text{Retained MRR} = \text{At-Risk MRR Base} \times \text{Retention Lift \%}$.*

---

## 8. Limitations & Methodological Constraints

1. **Small Sample Size ($n = 15$):** Statistical significance tests ($p$-values, confidence intervals) cannot be reliably computed. Rates of 100% and 0% reflect small sample group artifacts rather than permanent behavioral laws.
2. **Synthetic Data Nature:** The source dataset is clean and lacks real-world anomalies, unrecorded cancellations, or billing chargebacks.
3. **Absence of Time-Series Records:** The data lacks cancellation timestamps, preventing survival analysis (Kaplan-Meier hazard curves) or seasonal decomposition.
4. **In-Sample Score Validation:** The scoring model was calibrated on the same 15 records it evaluates; validation on out-of-sample data is essential before production deployment.
5. **Absence of Concession Cost Accounting:** The model does not include the operational cost of customer success labor or promotional discounting, which must be tracked in pilot testing.

---

## 9. Next Steps & Governance Roadmap

1. **Conduct Controlled A/B Testing:** Test the 15% annual migration discount against a control group of monthly subscribers to establish true elasticity and net incremental retention.
2. **Expand Data Infrastructure:** Ingest telemetry tracking user feature adoption, last login date, NPS feedback, and ticket resolution turnaround times across a target sample of 250–500 live accounts.
3. **Automate Risk Scoring in CRM:** Integrate the transparent rule-based score into the customer success pipeline to automatically generate escalation tasks for accounts crossing the 2.0-point threshold.
